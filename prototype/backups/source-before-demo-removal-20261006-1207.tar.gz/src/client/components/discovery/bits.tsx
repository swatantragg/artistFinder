// Small discovery widgets shared by the dossier, the Artist Discovery page, the queue and import results.
import { AlertTriangle, Check, CircleDot, ExternalLink, Loader2, Minus, X } from 'lucide-react';
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { Badge, Button, Empty, Modal, SkeletonRows, cx } from '../ui';
import { useQuery } from '../../lib/app';
import { fmtDateTime, num } from '../../lib/format';

// Platform marks use the theme's status tones, so they read in light and dark mode.
const PLATFORM_STYLE: Record<string, { short: string; tone: string }> = {
  Instagram: { short: 'IG', tone: 'violet' }, YouTube: { short: 'YT', tone: 'red' }, Spotify: { short: 'SP', tone: 'green' }, Facebook: { short: 'FB', tone: 'blue' },
  SoundCloud: { short: 'SC', tone: 'orange' }, X: { short: 'X', tone: 'neutral' }, Website: { short: 'WEB', tone: 'neutral' }, 'Label website': { short: 'LBL', tone: 'gold' },
  'Apple Music': { short: 'AM', tone: 'red' }, JioSaavn: { short: 'JS', tone: 'green' },
};
export function PlatformBadge({ platform, size = 'md' }: { platform: string; size?: 'sm' | 'md' }) {
  const s = PLATFORM_STYLE[platform] ?? { short: platform.slice(0, 3).toUpperCase(), tone: 'neutral' };
  return <span title={platform} className={cx(`tone-${s.tone} badge inline-flex shrink-0 items-center justify-center rounded-md font-semibold tracking-wide`, size === 'sm' ? 'h-5 min-w-[28px] px-1 text-3xs' : 'h-8 min-w-[38px] px-1.5 text-2xs')}>{s.short}</span>;
}
export function StrengthBadge({ strength }: { strength: string }) {
  const tone = strength === 'STRONG' ? 'green' : strength === 'POSSIBLE' ? 'gold' : 'neutral';
  return <Badge tone={tone} dot>{strength === 'STRONG' ? 'Strong candidate' : strength === 'POSSIBLE' ? 'Possible candidate' : 'Weak candidate'}</Badge>;
}
export function DemoTag() { return <span className="rounded border border-dashed border-[var(--t-orange-bd)] px-1 text-3xs font-semibold uppercase tracking-wide text-[var(--t-orange)]" title="Fictional result from DEMO DISCOVERY MODE, not from live search">Demo data</span>; }

const DISC_TONE: Record<string, 'neutral' | 'blue' | 'orange' | 'green' | 'red' | 'gold'> = { 'Not started': 'neutral', Queued: 'blue', Searching: 'blue', 'Needs verification': 'gold', Verified: 'green', 'No candidate': 'orange', Failed: 'red' };
export function DiscoveryChip({ status, extra }: { status: string; extra?: string }) {
  if (status === 'Not started') return <span className="whitespace-nowrap text-sm text-muted">Not started</span>;
  return (
    <Badge tone={DISC_TONE[status] ?? 'neutral'} dot>
      {(status === 'Searching' || status === 'Queued') && <Loader2 size={11} className="animate-spin" />}
      {status === 'No candidate' ? 'No verified candidate' : status}{extra ? ` ${extra}` : ''}
    </Badge>
  );
}
export function ReviewIcon({ status }: { status: string }) {
  if (status === 'VERIFIED') return <Check size={14} className="text-[var(--t-green)]" />;
  if (status === 'REJECTED' || status === 'REPLACED') return <X size={14} className="text-[var(--t-red)]" />;
  if (status === 'DEFERRED') return <Minus size={14} className="text-muted" />;
  return <CircleDot size={14} className="text-[var(--t-gold)]" />;
}

/** Matched evidence and conflicts, never hidden. */
export function EvidenceChips({ matched, conflicts, max = 6 }: { matched: string[]; conflicts: string[]; max?: number }) {
  const [all, setAll] = useState(false);
  const shown = all ? matched : matched.slice(0, max);
  return (
    <div className="space-y-1">
      {matched.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {shown.map(m => <span key={m} className="inline-flex items-center gap-1 rounded-md bg-[var(--t-green-bg)] px-1.5 py-0.5 text-xs text-[var(--t-green)]"><Check size={11} />{m}</span>)}
          {matched.length > max && <button type="button" className="text-xs text-muted underline" onClick={() => setAll(a => !a)}>{all ? 'less' : `+${matched.length - max} more`}</button>}
        </div>
      )}
      {conflicts.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {conflicts.map(c => <span key={c} className="inline-flex items-center gap-1 rounded-md bg-[var(--t-orange-bg)] px-1.5 py-0.5 text-xs text-[var(--t-orange)]"><AlertTriangle size={11} />{c}</span>)}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ profile links: real tab in live mode, preview for demo data
interface PreviewCtx { open(profileId: string): void }
const Ctx = createContext<PreviewCtx>({ open: () => undefined });
export function PreviewHost({ children }: { children: ReactNode }) {
  const [id, setId] = useState<string | null>(null);
  const open = useCallback((pid: string) => setId(pid), []);
  const value = useMemo(() => ({ open }), [open]);
  return <Ctx.Provider value={value}>{children}{id && <ProfilePreview id={id} onClose={() => setId(null)} />}</Ctx.Provider>;
}
export function ProfileLink({ url, demo, profileId, label = 'Open profile', small }: { url: string; demo: boolean; profileId?: string; label?: string; small?: boolean }) {
  const { open } = useContext(Ctx);
  const cls = cx('inline-flex items-center gap-1 rounded-md border border-line-strong bg-surface font-medium text-ink-2 hover:bg-hover', small ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-sm');
  if (demo && profileId) return <button type="button" className={cls} onClick={() => open(profileId)} title="Demo data: shows the fictional page instead of opening a real site">{label}<ExternalLink size={12} /></button>;
  return <a href={url} target="_blank" rel="noopener noreferrer" className={cls}>{label}<ExternalLink size={12} /></a>;
}
interface Preview { id: string; platform: string; url: string; displayName: string; username: string | null; title: string; description: string; location: string | null; language: string | null; links: string[]; tracks: { title: string; isrc?: string | null }[]; followers: number | null; demo: boolean; status: string; caseName: string | null; results: { provider: string; query: string; snippet: string; title: string; at: string }[]; source?: string }
function ProfilePreview({ id, onClose }: { id: string; onClose: () => void }) {
  const { data } = useQuery<Preview | null>('profilePreview', { id });
  return (
    <Modal open onClose={onClose} width={560} title={data ? <span className="flex items-center gap-2"><PlatformBadge platform={data.platform} size="sm" />{data.displayName}</span> : 'Profile'}
      description={data?.demo ? 'DEMO DATA: a fictional page from demo discovery mode. In live mode this button opens the real profile in a new tab.' : undefined}
      footer={data && !data.demo ? <a href={data.url} target="_blank" rel="noopener noreferrer"><Button variant="primary">Open the real page</Button></a> : <Button onClick={onClose}>Close</Button>}>
      {data === undefined ? <SkeletonRows rows={4} /> : data === null ? <Empty compact title="Profile not found." /> : (
        <div className="space-y-3 text-sm">
          <div className="rounded-lg border border-line bg-surface-2 p-3">
            <p className="mono break-all text-xs text-muted">{data.url}</p>
            <p className="mt-1 font-medium text-ink">{data.title}</p>
            <p className="mt-1 text-ink-2">{data.description || 'No description.'}</p>
            <p className="mt-1.5 text-xs text-muted">{[data.username && `@${data.username}`, data.location, data.language, data.followers != null && `${num(data.followers)} followers`].filter(Boolean).join(' · ')}</p>
          </div>
          {data.tracks.length > 0 && <div><p className="mb-1 text-xs font-medium text-muted">Songs listed</p><ul className="space-y-0.5">{data.tracks.map(t => <li key={t.title + (t.isrc ?? '')}>{t.title}{t.isrc && <span className="mono ml-2 text-xs text-muted">{t.isrc}</span>}</li>)}</ul></div>}
          {data.links.length > 0 && <div><p className="mb-1 text-xs font-medium text-muted">Links on the page</p><ul className="space-y-0.5">{data.links.map(l => <li key={l} className="mono break-all text-xs text-ink-2">{l}</li>)}</ul></div>}
          {data.results.length > 0 && <div><p className="mb-1 text-xs font-medium text-muted">Search results that found it</p><ul className="space-y-2">{groupResults(data.results).map(g => (
            <li key={g.snippet} className="text-xs text-ink-2">{g.snippet || <span className="text-muted">No snippet.</span>}
              <span className="mt-0.5 block text-muted">{g.hits.length === 1 ? 'Found by' : `Found by ${g.hits.length} searches`}: {g.hits.map(h => `${h.provider} ${h.query}`).join(' · ')} · {fmtDateTime(g.at)}</span>
            </li>))}</ul></div>}
        </div>
      )}
    </Modal>
  );
}
/** The same page usually comes back for several queries: show its snippet once with every query that found it. */
function groupResults(results: Preview['results']) {
  const groups = new Map<string, { snippet: string; at: string; hits: { provider: string; query: string }[] }>();
  for (const r of results) {
    const g = groups.get(r.snippet) ?? { snippet: r.snippet, at: r.at, hits: [] };
    if (!g.hits.some(h => h.provider === r.provider && h.query === r.query)) g.hits.push({ provider: r.provider, query: r.query });
    if (r.at > g.at) g.at = r.at;
    groups.set(r.snippet, g);
  }
  return [...groups.values()];
}

// ------------------------------------------------------------------ search budget (API usage limits from .env)
interface Usage { id: string; label: string; perArtist: number | null; remaining: number | null; month: { used: number; limit: number; resetsOn: string } | null; day: { used: number; limit: number; resetsOn: string } | null }
export interface DiscoveryConfigV { mode: string; notes: string[]; providers: { id: string; label: string; kind: string; demo: boolean }[]; staleDays: number; demoOutage: boolean; running: number; blocked: string | null; usage: Usage[]; budget: { artists: number; exhausted: string | null } | null }
const pct = (used: number, limit: number) => Math.min(100, Math.round((used / limit) * 100));
/** Used / limit per search API, with a bar per period; `compact` puts everything on one line. */
export function SearchBudget({ cfg, compact }: { cfg: DiscoveryConfigV; compact?: boolean }) {
  if (!cfg.usage?.length) return null;
  const periods = (u: Usage) => [u.day && { name: 'today', ...u.day }, u.month && { name: 'this month', ...u.month }].filter(Boolean) as { name: string; used: number; limit: number; resetsOn: string }[];
  if (compact) return (
    <p className="text-xs text-muted tnum">
      Search limits: {cfg.usage.map(u => `${u.label} ${periods(u).map(p => `${num(p.used)}/${num(p.limit)} ${p.name}`).join(', ') || 'no limit'}`).join(' · ')}
      {cfg.budget && <> · <span className={cfg.budget.exhausted ? 'font-medium text-[var(--t-red)]' : 'text-ink-2'}>{cfg.budget.exhausted ? 'limit reached' : `room for about ${num(cfg.budget.artists)} more artist search${cfg.budget.artists === 1 ? '' : 'es'}`}</span></>}
    </p>
  );
  return (
    <ul className="space-y-2.5">
      {cfg.usage.map(u => (
        <li key={u.id} className="text-sm">
          <p className="flex flex-wrap items-baseline justify-between gap-2"><span className="font-medium text-ink">{u.label}</span>{u.perArtist && <span className="text-xs text-muted">at most {u.perArtist} per artist</span>}</p>
          {periods(u).map(p => (
            <div key={p.name} className="mt-1">
              <div className="flex justify-between text-xs text-muted tnum"><span>{num(p.used)} / {num(p.limit)} {p.name}</span><span>resets {p.resetsOn}</span></div>
              <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-hover"><div className={cx('h-full rounded-full', p.used >= p.limit ? 'bg-[var(--t-red)]' : pct(p.used, p.limit) >= 80 ? 'bg-[var(--t-orange)]' : 'bg-[var(--t-green)]')} style={{ width: `${pct(p.used, p.limit)}%` }} /></div>
            </div>
          ))}
          {!periods(u).length && <p className="text-xs text-muted">No monthly or daily limit</p>}
        </li>
      ))}
      {cfg.budget && <li className={cx('text-xs', cfg.budget.exhausted ? 'font-medium text-[var(--t-red)]' : 'text-muted')}>{cfg.budget.exhausted ?? `Room for about ${num(cfg.budget.artists)} more complete artist search${cfg.budget.artists === 1 ? '' : 'es'} in this period.`}</li>}
    </ul>
  );
}
