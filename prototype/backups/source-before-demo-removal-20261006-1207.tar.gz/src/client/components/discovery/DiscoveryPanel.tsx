// One artist's discovery: Find artist, live progress, verified knowledge, candidates with evidence, history.
// Software suggests; every Verify / Reject / Keep separate is a person's decision.
import { AlertTriangle, Check, ChevronRight, FlaskConical, History, Loader2, RefreshCcw, Search, SearchX, Share2, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useActions } from '../actions';
import { Badge, Button, Card, Empty, ErrorBox, Notice, Skeleton, cx } from '../ui';
import { useApp, useQuery } from '../../lib/app';
import { fmtAgo, fmtDate, fmtDateTime, num, plural } from '../../lib/format';
import { DemoTag, DiscoveryChip, EvidenceChips, PlatformBadge, ProfileLink, ReviewIcon, StrengthBadge } from './bits';

export interface ProfileV {
  id: string; platform: string; url: string; displayName: string; username: string | null; title: string; description: string; location: string | null; strength: string; score: number;
  matched: string[]; conflicts: string[]; foundThrough: string[]; providers: string[]; queries: { provider: string; query: string; kind: string; version: number }[]; status: string; discoveryStatus: string;
  reviewNote: string | null; rejectionReason: string | null; reviewedBy: string | null; reviewedAt: string | null; verifiedAt: string | null; verifiedBy: string | null; lastCheckedAt: string; demo: boolean;
  groupKey: string | null; changeOfProfileId: string | null; version: number; newEvidence: boolean; foundWhileSearching: string | null; otherCase: { id: string; name: string; artistId: string | null } | null;
}
interface Step { label: string; state: string; detail: string | null }
export interface JobV {
  id: string; version: number; mode: string; status: string; trigger: string; focus: string[]; requestedBy: string; demo: boolean; step: number; steps: Step[];
  providers: { id: string; label: string; kind: string; demo: boolean; status: string; queries: number; results: number; cached: number; error: string | null }[];
  queryCount: number; cachedCount: number; resultCount: number; profileCount: number; newProfileCount: number; groupCount: number; pathCount: number; outcome: string | null; failureReason: string | null;
  attempt: number; createdAt: string; startedAt: string | null; finishedAt: string | null; durationMs: number | null; verified: number; rejected: number; needsReview: number; bulkId: string | null;
}
export interface DiscoveryData {
  caseId: string; name: string; artistId: string | null; artistIds: string[]; stage: string; contactPreference: string; owner: string; discoveryStatus: string; verifiedArtist: boolean; lastVerifiedAt: string | null;
  catalogue: { songs: number; credits: number; collaborators: number; isrcs: number; labels: number; releases: number; labelNames: string[]; roles: string[]; language: string | null; sampleSongs: string[]; isrcSample: string[] };
  verified: { id: string; profileId: string | null; platform: string; url: string; username: string | null; displayName: string; verifiedAt: string; verifiedBy: string; lastCheckedAt: string; daysSinceCheck: number; stale: boolean; source: string; evidence: string; demo: boolean; notFound: boolean; change: ProfileV | null }[];
  groups: { key: string; label: string; strength: string; strengthLabel: string; bestScore: number; displayName: string; profiles: ProfileV[]; verifiedProfiles: ProfileV[]; matched: string[]; conflicts: string[]; foundThrough: string[]; providers: string[]; otherCase: { id: string; name: string; artistId: string | null } | null; locations: string[] }[];
  multiple: boolean; changes: { next: ProfileV; old: ProfileV | null }[]; deferred: ProfileV[]; rejected: ProfileV[]; replaced: ProfileV[];
  jobs: JobV[]; activeJob: JobV | null; lastJob: JobV | null; noResult: { queries: { query: string; provider: string; status: string; results: number }[]; sources: string[]; durationMs: number | null; finishedAt: string | null } | null;
  collaborators: { name: string; caseId: string | null; roles: string[]; songs: string[]; songCount: number; verifiedProfiles: number; verifiedContacts: number; candidates: number; record: string | null; analysed: boolean }[];
  paths: unknown[]; staleDays: number; staleCount: number; demo: boolean; canFind: boolean; canRefresh: boolean; blocked: string | null; limit: string | null;
}

/** Discovery for one artist; polls quickly only while a search is running. */
export function useDiscovery(caseId: string) {
  const [fast, setFast] = useState(false);
  const q = useQuery<DiscoveryData | null>('discoveryDetail', { id: caseId }, { poll: fast ? 800 : false });
  const active = !!q.data?.activeJob;
  useEffect(() => { setFast(active); }, [active]);
  return q;
}

export function DiscoveryPanel({ caseId, showGraphLink = true }: { caseId: string; showGraphLink?: boolean }) {
  const { data, error } = useDiscovery(caseId);
  const app = useApp();
  const { open } = useActions();
  const navigate = useNavigate();
  const [busy, setBusy] = useState<string | null>(null);
  const cfg = useQuery<{ mode: string; notes: string[]; providers: { label: string; demo: boolean }[] }>('discoveryConfig');
  if (error) return <ErrorBox text={error} />;
  if (data === null) return <Empty title="Case not found." />;
  if (!data) return <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-64" /></div>;
  const start = async (mode: 'full' | 'refresh') => { setBusy(mode); await app.run('startDiscovery', { caseId, mode }); setBusy(null); };
  const findConnection = async () => { setBusy('connect'); await app.run('findConnection', { caseId }); setBusy(null); navigate(`/artists/${caseId}?tab=graph`); };
  const live = cfg.data?.mode === 'live';
  const job = data.activeJob;
  const last = data.lastJob;
  const openCount = data.groups.reduce((n, g) => n + g.profiles.length, 0);
  return (
    <div className="space-y-4">
      {data.limit && !data.blocked && !job && <Notice tone="orange" icon={<SearchX size={16} />} title="Search limit reached">{data.limit} Manual research stays available.</Notice>}
      {data.blocked ? <Notice tone="red" icon={<SearchX size={16} />} title="Discovery is off for this catalogue">{data.blocked} Manual research stays available.</Notice> : cfg.data && (live
        ? <Notice tone="blue" icon={<Search size={16} />} title="Live search">{cfg.data.notes[0]}</Notice>
        : <Notice tone="orange" icon={<FlaskConical size={16} />} title="Demo discovery mode: results are DEMO DATA">Real search is not configured, so Find artist searches a fictional demo web with the same pipeline. Nothing here comes from live search.</Notice>)}

      {/* Header: status, catalogue evidence, main actions */}
      <section className="rounded-lg border border-line bg-surface p-4 shadow-[var(--shadow)]">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-semibold text-ink">Artist discovery</h2>
              <DiscoveryChip status={data.discoveryStatus} />
              {data.multiple && <Badge tone="orange">Multiple candidates</Badge>}
              {data.staleCount > 0 && <Badge tone="orange">{data.staleCount} stale profile{data.staleCount === 1 ? '' : 's'}</Badge>}
            </div>
            <p className="mt-1 text-sm text-muted">
              {last ? <>Last search v{last.version} ({last.mode}) {last.finishedAt ? `${fmtDateTime(last.finishedAt)}` : 'running'}{last.durationMs != null ? ` · ${(last.durationMs / 1000).toFixed(1)} s` : ''} · by {last.requestedBy}</> : 'Never searched. Find artist searches the web, music services and collaborators for you.'}
            </p>
            <p className="mt-1.5 text-sm text-ink-2">
              <span className="text-muted">Catalogue evidence used: </span>
              {plural(data.catalogue.songs, 'song')} · {plural(data.catalogue.credits, 'credit')} · {plural(data.catalogue.collaborators, 'collaborator')} · {plural(data.catalogue.isrcs, 'ISRC')} · {data.catalogue.labelNames.join(', ') || 'no label'}{data.catalogue.roles.length ? ` · ${data.catalogue.roles.join(', ')}` : ''}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {data.canFind && <Button variant="primary" icon={<Search size={15} />} loading={busy === 'full'} disabled={!!data.blocked || !!data.limit} onClick={() => start('full')}>{data.discoveryStatus === 'Failed' ? 'Retry Find artist' : 'Find artist'}</Button>}
            {!data.canFind && data.canRefresh && <Button icon={<RefreshCcw size={14} />} loading={busy === 'refresh'} onClick={() => start('refresh')} disabled={!!job || !!data.blocked || !!data.limit}>Refresh search</Button>}
            {(data.verifiedArtist || last) && <Button icon={<Share2 size={14} />} loading={busy === 'connect'} onClick={findConnection}>Find connection</Button>}
            {showGraphLink && <Button variant="ghost" onClick={() => navigate(`/artists/${caseId}?tab=graph`)}>Connection graph</Button>}
          </div>
        </div>
      </section>

      {job && <JobProgress job={job} name={data.name} />}
      {!job && last?.status === 'FAILED' && (
        <Notice tone="red" icon={<AlertTriangle size={16} />} title="Discovery failed (the artist was not searched completely)"
          action={<Button size="sm" variant="primary" onClick={async () => { setBusy('retry'); await app.run('retryDiscovery', { jobId: last.id }); setBusy(null); }} loading={busy === 'retry'}>Retry</Button>}>
          {last.failureReason}. This does not mean the artist does not exist.
        </Notice>
      )}
      {!job && !last && !data.verifiedArtist && <NotStarted blocked={!!data.blocked} />}
      {!job && data.noResult && (
        <Card title="No verified candidate found" subtitle="Nothing usable came back from the sources below. The case stays open; it is never deleted.">
          <div className="grid gap-4 md:grid-cols-3 text-sm">
            <div><p className="mb-1 text-xs font-medium text-muted">Sources searched</p><ul className="space-y-0.5">{data.noResult.sources.map(s => <li key={s}>{s}</li>)}</ul></div>
            <div><p className="mb-1 text-xs font-medium text-muted">Search time</p><p>{data.noResult.durationMs != null ? `${(data.noResult.durationMs / 1000).toFixed(1)} s` : '—'} · {fmtDateTime(data.noResult.finishedAt)}</p><p className="mt-2 mb-1 text-xs font-medium text-muted">Catalogue evidence available</p><p>{data.catalogue.sampleSongs.slice(0, 3).map(s => `“${s}”`).join(', ')}{data.catalogue.isrcSample.length ? ` · ISRC ${data.catalogue.isrcSample[0]}` : ''}</p></div>
            <div><p className="mb-1 text-xs font-medium text-muted">Queries attempted ({data.noResult.queries.length})</p><ul className="max-h-32 space-y-0.5 overflow-y-auto scroll-thin">{[...new Set(data.noResult.queries.map(q => q.query))].map(q => <li key={q} className="mono text-xs">{q}</li>)}</ul></div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="primary" onClick={() => start('refresh')}>Retry</Button>
            <Button size="sm" onClick={() => open('addResearch', { caseId })}>Add manual evidence</Button>
            <Button size="sm" onClick={() => app.run('waitForNewEvidence', { caseId })}>Wait for new evidence</Button>
          </div>
        </Card>
      )}

      {data.verified.length > 0 && <VerifiedCard data={data} onRefresh={() => start('refresh')} />}

      {data.groups.length > 0 && (
        <section className="space-y-3">
          <header className="flex flex-wrap items-baseline justify-between gap-2">
            <h3 className="text-md font-semibold text-ink">{plural(openCount, 'candidate profile')} in {plural(data.groups.length, 'possible artist')}</h3>
            <p className="text-xs text-muted">Possible artists, not identities. Discovery evidence score = how much catalogue evidence points to a profile. Only a person verifies.</p>
          </header>
          {data.groups.map(g => <GroupCard key={g.key} caseId={caseId} g={g} name={data.name} />)}
        </section>
      )}

      {data.deferred.length > 0 && (
        <Card title={`Review later (${data.deferred.length})`} pad={false}>
          <ul className="divide-y divide-line">{data.deferred.map(p => <li key={p.id} className="px-4 py-3"><ProfileRow p={p} caseId={caseId} compact /></li>)}</ul>
        </Card>
      )}
      {(data.rejected.length > 0 || data.replaced.length > 0) && <RejectedCard rejected={data.rejected} replaced={data.replaced} />}
      {data.collaborators.length > 0 && <CollaboratorsCard list={data.collaborators} />}
      {data.jobs.length > 0 && <HistoryCard jobs={data.jobs} />}
    </div>
  );
}

function NotStarted({ blocked }: { blocked?: boolean }) {
  return (
    <Card title="Not searched yet">
      <p className="text-sm text-ink-2">{blocked ? <>Find artist is off for this catalogue (see above); use <b>Research manually</b> for now. When real search is configured, the software reads</> : <>Click <b>Find artist</b>. The software reads</>} the catalogue (songs, ISRCs, labels, credits, collaborators), builds search queries, searches the web and music services, follows collaborators, groups what it finds into possible artists and explains every result. You then verify or reject. Verified profiles are remembered for every future import.</p>
      <ol className="mt-3 grid gap-1.5 text-sm text-muted sm:grid-cols-2 lg:grid-cols-4">
        {['Generating queries', 'Searching web', 'Searching supported APIs', 'Analyzing songs', 'Analyzing collaborators', 'Building graph', 'Preparing candidates'].map((s, i) => <li key={s} className="flex items-center gap-1.5"><span className="flex h-5 w-5 items-center justify-center rounded-full bg-hover text-2xs font-semibold text-ink-2">{i + 1}</span>{s}</li>)}
      </ol>
    </Card>
  );
}

export function JobProgress({ job, name }: { job: JobV; name: string }) {
  const n = job.steps.length;
  const current = Math.min(job.step, n - 1);
  return (
    <section className="rounded-lg border border-[var(--t-blue-bd)] bg-surface p-4 shadow-[var(--shadow)]">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-base font-semibold text-ink"><Loader2 size={16} className="animate-spin text-[var(--t-blue)]" />{job.status === 'QUEUED' ? `Queued: finding ${name}…` : `Finding ${name}… Step ${current + 1}/${n} ${job.steps[current]?.label}`}</p>
        <p className="text-xs text-muted">{job.mode === 'targeted' ? 'Targeted search' : job.mode === 'refresh' ? 'Refresh' : 'Full search'} v{job.version} · {num(job.queryCount)} provider calls · {num(job.resultCount)} results{job.demo ? ' · demo data' : ''}</p>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-hover"><div className="h-full rounded-full bg-[var(--t-blue)] transition-all" style={{ width: `${((job.status === 'QUEUED' ? 0 : current + 0.5) / n) * 100}%` }} /></div>
      <ol className="mt-3 grid gap-1.5 text-sm sm:grid-cols-2 lg:grid-cols-4">
        {job.steps.map((s, i) => (
          <li key={s.label} className={cx('flex items-start gap-1.5', s.state === 'todo' && 'text-faint')}>
            {s.state === 'done' ? <Check size={14} className="mt-0.5 text-[var(--t-green)]" /> : s.state === 'running' ? <Loader2 size={14} className="mt-0.5 animate-spin text-[var(--t-blue)]" /> : s.state === 'failed' ? <AlertTriangle size={14} className="mt-0.5 text-[var(--t-red)]" /> : <span className="mt-1 h-2.5 w-2.5 rounded-full border border-line-strong" />}
            <span><span className={cx(s.state !== 'todo' && 'text-ink')}>{i + 1}. {s.label}</span>{s.detail && <span className="block text-xs text-muted">{s.detail}</span>}</span>
          </li>
        ))}
      </ol>
      {job.focus.length > 0 && <p className="mt-2 text-xs text-muted">Searching around: {job.focus.join(' · ')}</p>}
      <p className="mt-2 text-xs text-muted">Runs in the background: you can keep working. You get a notification when it finishes.</p>
    </section>
  );
}

function VerifiedCard({ data, onRefresh }: { data: DiscoveryData; onRefresh: () => void }) {
  const { open } = useActions();
  return (
    <section className="rounded-lg border border-[var(--t-green-bd)] bg-surface shadow-[var(--shadow)]">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-2.5">
        <p className="flex items-center gap-2 text-sm font-semibold text-ink"><Check size={15} className="text-[var(--t-green)]" />Verified artist · {plural(data.verified.length, 'verified profile')}</p>
        <p className="text-xs text-muted">Last verified {fmtDate(data.lastVerifiedAt)} · future imports reuse these without searching again</p>
      </header>
      <ul className="divide-y divide-line">
        {data.verified.map(v => (
          <li key={v.id} className="px-4 py-2.5">
            <div className="flex flex-wrap items-center gap-3">
              <PlatformBadge platform={v.platform} />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink">{v.platform} {v.username && !/^2Demo|^UC/.test(v.username) ? `@${v.username}` : v.displayName} {v.demo && <DemoTag />}</p>
                <p className="text-xs text-muted">Verified by {v.verifiedBy} on {fmtDate(v.verifiedAt)} · {v.stale ? <span className="font-medium text-[var(--t-orange)]">STALE: last checked {v.daysSinceCheck} days ago (threshold {data.staleDays})</span> : `checked ${fmtAgo(v.lastCheckedAt)}`}{v.notFound ? ' · not found in the latest search' : ''}</p>
              </div>
              <ProfileLink url={v.url} demo={v.demo} profileId={v.profileId ?? undefined} small />
              {v.stale && <Button size="sm" onClick={onRefresh}>Refresh</Button>}
            </div>
            {v.change && (
              <div className="mt-2 rounded-md border border-[var(--t-orange-bd)] bg-[var(--t-orange-bg)] px-3 py-2 text-sm">
                <p className="font-semibold text-[var(--t-orange)]">PROFILE CHANGE DETECTED</p>
                <p className="text-ink-2">Old: <b>{v.username ? `@${v.username}` : v.url}</b> (verified) → New: <b>{v.change.username ? `@${v.change.username}` : v.change.url}</b> <span className="text-muted">found in search v{v.change.version}; not overwritten</span></p>
                <EvidenceChips matched={v.change.matched} conflicts={v.change.conflicts} max={4} />
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <ProfileLink url={v.change.url} demo={v.change.demo} profileId={v.change.id} small label="Open new" />
                  <Button size="sm" variant="primary" onClick={() => open('resolveProfileChange', { caseId: data.caseId, preset: { profileId: v.change!.id, decision: 'verify_new' } })}>Verify new</Button>
                  <Button size="sm" onClick={() => open('resolveProfileChange', { caseId: data.caseId, preset: { profileId: v.change!.id, decision: 'keep_old' } })}>Keep old</Button>
                  <Button size="sm" variant="danger" onClick={() => open('resolveProfileChange', { caseId: data.caseId, preset: { profileId: v.change!.id, decision: 'reject_new' } })}>Reject new</Button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}

function GroupCard({ caseId, g, name }: { caseId: string; g: DiscoveryData['groups'][number]; name: string }) {
  const { open } = useActions();
  const app = useApp();
  const weakOnly = g.strength === 'WEAK';
  return (
    <section className={cx('rounded-lg border bg-surface shadow-[var(--shadow)]', g.otherCase ? 'border-[var(--t-orange-bd)]' : g.strength === 'STRONG' ? 'border-[var(--t-green-bd)]' : 'border-line')}>
      <header className="border-b border-line px-4 py-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-2xs font-semibold uppercase tracking-wider text-muted">Possible artist · {g.label}</p>
            <p className="text-lg font-semibold text-ink">{g.displayName} <span className="text-sm font-normal text-muted">· {plural(g.profiles.length, 'profile')}{g.locations.length ? ` · ${g.locations.join(' / ')}` : ''}{g.verifiedProfiles.length ? ` · ${g.verifiedProfiles.length} already verified` : ''}</span></p>
          </div>
          <div className="flex items-center gap-2"><StrengthBadge strength={g.strength} /><span className="text-xs text-muted" title="Discovery evidence score (not an identity confidence)">score {g.bestScore}</span></div>
        </div>
        {g.otherCase && <p className="mt-2 rounded-md bg-[var(--t-orange-bg)] px-2.5 py-1.5 text-sm text-[var(--t-orange)]">The songs here belong to <Link className="font-medium underline" to={`/artists/${g.otherCase.id}?tab=evidence`}>{g.otherCase.name} ({g.otherCase.artistId ?? g.otherCase.id})</Link>, a different artist with the same name. Names alone never merge artists.</p>}
        <div className="mt-2"><EvidenceChips matched={g.matched} conflicts={g.conflicts} max={5} /></div>
        <p className="mt-1.5 text-xs text-muted">Found through: {g.foundThrough.join(' · ')} <span className="text-faint">({g.providers.join(', ')})</span></p>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {!g.otherCase && !weakOnly && <Button size="sm" variant="primary" onClick={() => open('verifyCandidateGroup', { caseId, preset: { groupKey: g.key, count: g.profiles.length, name } })}>Verify all {g.profiles.length}</Button>}
          <Button size="sm" variant="danger" onClick={() => open('rejectCandidateGroup', { caseId, preset: { groupKey: g.key } })}>Reject</Button>
          <Button size="sm" variant={g.otherCase ? 'primary' : 'secondary'} onClick={() => open('keepSeparateGroup', { caseId, preset: { groupKey: g.key, other: g.otherCase } })}>Keep separate</Button>
          <Button size="sm" variant="ghost" onClick={() => app.run('deferCandidateGroup', { caseId, groupKey: g.key })}>Review later</Button>
        </div>
      </header>
      <ul className="divide-y divide-line">{g.profiles.map(p => <li key={p.id} className="px-4 py-3"><ProfileRow p={p} caseId={caseId} /></li>)}</ul>
    </section>
  );
}

export function ProfileRow({ p, caseId, compact }: { p: ProfileV; caseId: string; compact?: boolean }) {
  const { open } = useActions();
  const app = useApp();
  return (
    <div className="flex flex-wrap items-start gap-3">
      <PlatformBadge platform={p.platform} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-base font-medium text-ink">{p.platform} {p.username && !/^2Demo|^UC/.test(p.username) ? `@${p.username}` : <span className="font-normal">“{p.displayName}”</span>}</p>
          <StrengthBadge strength={p.strength} />
          <span className="text-xs text-muted" title="Discovery evidence score: how much catalogue evidence points here. Never an identity decision.">score {p.score}</span>
          {p.demo && <DemoTag />}
          {p.status !== 'UNREVIEWED' && <span className="inline-flex items-center gap-1 text-xs text-muted"><ReviewIcon status={p.status} />{p.status.toLowerCase()}</span>}
        </div>
        <p className="mono break-all text-xs text-muted">{p.url}</p>
        {!compact && <p className="mt-1 line-clamp-2 text-sm text-ink-2">{p.description}</p>}
        {p.foundWhileSearching && <p className="text-xs text-muted">Found while searching {p.foundWhileSearching}</p>}
        <div className="mt-1.5"><p className="mb-0.5 text-xs font-medium text-muted">Found because</p><EvidenceChips matched={p.matched} conflicts={p.conflicts} max={compact ? 3 : 5} /></div>
        {!compact && <p className="mt-1 text-xs text-muted">Found through: {p.foundThrough.join(' · ')}</p>}
        {p.reviewNote && <p className="mt-1 text-xs text-muted">Note: {p.reviewNote}{p.reviewedBy ? ` (${p.reviewedBy})` : ''}</p>}
      </div>
      <div className="flex shrink-0 flex-wrap gap-1.5">
        <ProfileLink url={p.url} demo={p.demo} profileId={p.id} small />
        {(p.status === 'UNREVIEWED' || p.status === 'DEFERRED') && <>
          <Button size="sm" variant="primary" onClick={() => open('verifyProfile', { caseId, preset: { profileId: p.id, label: `${p.platform} ${p.username ? `@${p.username}` : p.displayName}` } })}>Verify</Button>
          <Button size="sm" variant="danger" onClick={() => open('rejectProfile', { caseId, preset: { profileId: p.id } })}>Reject</Button>
          {p.status === 'UNREVIEWED' && <Button size="sm" variant="ghost" onClick={() => app.run('deferProfile', { profileId: p.id })}>Later</Button>}
        </>}
      </div>
    </div>
  );
}

function RejectedCard({ rejected, replaced }: { rejected: ProfileV[]; replaced: ProfileV[] }) {
  const app = useApp();
  const [openList, setOpen] = useState(false);
  return (
    <Card title={`Rejected (${rejected.length})${replaced.length ? ` · replaced (${replaced.length})` : ''}`} subtitle="Kept with the reason, so the same bad result is not shown again" actions={<Button size="sm" variant="ghost" onClick={() => setOpen(o => !o)}>{openList ? 'Hide' : 'Show'}</Button>} pad={false}>
      {openList && (
        <ul className="divide-y divide-line">
          {[...rejected, ...replaced].map(p => (
            <li key={p.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-sm">
              <PlatformBadge platform={p.platform} size="sm" />
              <span className="min-w-0 flex-1"><span className="text-ink">{p.platform} {p.username ? `@${p.username}` : p.displayName}</span> {p.demo && <DemoTag />}<span className="block text-xs text-muted">{p.status === 'REPLACED' ? p.reviewNote : `Reason: ${p.rejectionReason}`}{p.reviewedBy ? ` · ${p.reviewedBy}` : ''}{p.reviewedAt ? `, ${fmtDate(p.reviewedAt)}` : ''}</span>{p.newEvidence && <span className="text-xs font-medium text-[var(--t-gold)]">New evidence since rejection</span>}</span>
              {p.status === 'REJECTED' && <Button size="sm" variant={p.newEvidence ? 'primary' : 'secondary'} onClick={() => app.run('reconsiderProfile', { profileId: p.id })}>Reconsider</Button>}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function CollaboratorsCard({ list }: { list: DiscoveryData['collaborators'] }) {
  return (
    <Card title={<span className="flex items-center gap-2"><Users size={14} />Collaborators analysed</span>} subtitle="A collaborator credited on a song is a research lead, not proof of a personal relationship" pad={false}>
      <ul className="divide-y divide-line">
        {list.map(c => (
          <li key={c.name} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2 text-sm">
            <span>{c.caseId ? <Link to={`/artists/${c.caseId}?tab=evidence`} className="font-medium text-ink underline decoration-line-strong hover:decoration-ink">{c.name}</Link> : <span className="font-medium">{c.name}</span>} <span className="text-muted">· {c.roles.join(', ')} on {plural(c.songCount, 'song')}</span></span>
            <span className="flex flex-wrap gap-1.5 text-xs">
              {c.verifiedProfiles > 0 ? <Badge tone="green" dot>{c.verifiedProfiles} verified profile{c.verifiedProfiles === 1 ? '' : 's'} reused</Badge> : <Badge>No verified profile</Badge>}
              {c.verifiedContacts > 0 && <Badge tone="green" dot>Verified contact</Badge>}
              {!c.caseId && <Badge tone="orange">Candidate collaborator record</Badge>}
            </span>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function HistoryCard({ jobs }: { jobs: JobV[] }) {
  const [openId, setOpenId] = useState<string | null>(null);
  return (
    <Card title={<span className="flex items-center gap-2"><History size={14} />Search history</span>} subtitle="Every version is kept. Old evidence is never deleted." pad={false}>
      <ul className="divide-y divide-line">
        {jobs.map(j => (
          <li key={j.id}>
            <button type="button" onClick={() => setOpenId(openId === j.id ? null : j.id)} className="flex w-full flex-wrap items-center gap-x-4 gap-y-1 px-4 py-2.5 text-left text-sm hover:bg-hover">
              <ChevronRight size={14} className={cx('text-muted transition-transform', openId === j.id && 'rotate-90')} />
              <span className="font-medium text-ink">v{j.version} · {j.mode === 'full' ? 'Full search' : j.mode === 'refresh' ? 'Refresh' : 'Targeted'}</span>
              <StatusMini status={j.status} />
              <span className="text-muted">{fmtDateTime(j.startedAt ?? j.createdAt)}{j.finishedAt ? ` → ${fmtDateTime(j.finishedAt)}` : ''}</span>
              <span className="text-muted">{j.trigger}</span>
              <span className="ml-auto text-xs text-muted tnum">{j.queryCount} queries{j.cachedCount ? ` (${j.cachedCount} cached)` : ''} · {j.providers.filter(p => p.status !== 'skipped').length} sources · {j.profileCount} candidates · {j.verified} verified · {j.rejected} rejected · {j.needsReview} need review</span>
            </button>
            {openId === j.id && <JobQueries job={j} />}
          </li>
        ))}
      </ul>
    </Card>
  );
}
function StatusMini({ status }: { status: string }) {
  const tone = status === 'FAILED' ? 'red' : status === 'NEEDS_REVIEW' ? 'gold' : status === 'COMPLETED' ? 'green' : 'blue';
  return <Badge tone={tone}>{status.replace('_', ' ').toLowerCase()}</Badge>;
}
function JobQueries({ job }: { job: JobV }) {
  const { data } = useQuery<{ id: string; provider: string; query: string; kind: string; subject: string; status: string; results: number; error: string | null }[]>('discoveryJobQueries', { jobId: job.id });
  return (
    <div className="border-t border-line bg-surface-2 px-4 py-3 text-xs">
      {job.failureReason && <p className="mb-2 text-[var(--t-red)]">{job.failureReason}</p>}
      <div className="mb-2 flex flex-wrap gap-2">{job.providers.map(p => <span key={p.id} className="rounded border border-line bg-surface px-1.5 py-0.5">{p.label}: {p.status}{p.queries ? ` · ${p.queries} calls · ${p.results} results` : ''}{p.cached ? ` · ${p.cached} cached` : ''}</span>)}</div>
      {!data ? <Skeleton className="h-16" /> : (
        <div className="scroll-thin max-h-64 overflow-auto">
          <table className="w-full text-left">
            <thead><tr className="text-muted"><th className="py-1 pr-3 font-medium">Query</th><th className="py-1 pr-3 font-medium">Kind</th><th className="py-1 pr-3 font-medium">Source</th><th className="py-1 pr-3 font-medium">Result</th></tr></thead>
            <tbody>{data.map(q => <tr key={q.id} className="border-t border-line"><td className="mono py-1 pr-3">{q.query}</td><td className="py-1 pr-3">{q.kind}</td><td className="py-1 pr-3">{q.provider}</td><td className={cx('py-1 pr-3', q.status === 'failed' && 'text-[var(--t-red)]')}>{q.status === 'ok' ? `${q.results} results` : q.status === 'cached' ? `${q.results} (cached)` : q.status}{q.error ? `: ${q.error}` : ''}</td></tr>)}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
