// Interactive connection graph (React Flow). Solid = verified by a person, normal = discovered with a source,
// dashed = possible. Labels and icons carry the same meaning, so colour is never the only signal.
import { Background, Controls, Handle, Position, ReactFlow, ReactFlowProvider, useReactFlow, type Edge, type Node, type NodeProps } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { AtSign, Building2, Disc3, ExternalLink, Minus, Music2, Phone, Plus, RotateCcw, Route as RouteIcon, Share2, ShieldCheck, Star, Truck, User, Waypoints } from 'lucide-react';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useActions } from '../actions';
import { Badge, Button, Empty, Segmented, Skeleton, cx } from '../ui';
import { useApp, useQuery } from '../../lib/app';
import { fmtDate } from '../../lib/format';
import { ProfileLink } from './bits';

interface ViewNode { id: string; type: string; label: string; sub: string | null; url: string | null; level: number; refId: string | null; status: string | null; root?: boolean; demo?: boolean }
interface ViewEdge { id: string; source: string; target: string; type: string; label: string; status: 'verified' | 'discovered' | 'possible' | 'rejected'; evidence: string; sourceLabel: string; sourceUrl: string | null; sourceType: string; discoveredAt: string; verifiedAt: string | null; verifiedBy: string | null; confidence: number; derived?: boolean }
export interface GraphData { root: string; nodes: ViewNode[]; edges: ViewEdge[]; hidden: { songs: number }; caseId: string; name: string; contactPreference: string }
interface PathLite { id: string; steps: { nodeId: string; label: string }[] }

const TYPE_ICON: Record<string, ReactNode> = {
  Artist: <User size={13} />, Person: <User size={13} />, Collaborator: <User size={13} />, Song: <Music2 size={13} />, Release: <Disc3 size={13} />, Label: <Building2 size={13} />,
  Distributor: <Truck size={13} />, Profile: <AtSign size={13} />, Contact: <Phone size={13} />, Route: <RouteIcon size={13} />,
};
const GROUPS: { id: string; label: string; types: string[] }[] = [
  { id: 'people', label: 'People', types: ['Artist', 'Person', 'Collaborator'] }, { id: 'songs', label: 'Songs', types: ['Song', 'Release'] }, { id: 'labels', label: 'Labels', types: ['Label', 'Distributor'] },
  { id: 'profiles', label: 'Profiles', types: ['Profile'] }, { id: 'contacts', label: 'Contacts', types: ['Contact'] }, { id: 'routes', label: 'Routes', types: ['Route'] },
];
const STATUSES = [{ id: 'verified', label: '✓ Verified' }, { id: 'discovered', label: 'Discovered' }, { id: 'possible', label: '? Possible' }] as const;
// Edges whose meaning the node already shows: labelled only on a highlighted path or around the selection.
const QUIET = new Set(['ARTIST_HAS_PROFILE', 'PERSON_HAS_PROFILE', 'PROFILE_SUPPORTS_IDENTITY', 'ROUTE_CONNECTS_ARTIST', 'ROUTE_USES_CONTACT']);
const TYPE_ORDER = ['Profile', 'Contact', 'Route', 'Song', 'Release', 'Artist', 'Person', 'Collaborator', 'Label', 'Distributor'];

type FlowNode = Node<{ view: ViewNode; highlight: boolean }>;
function EntityNode({ data, selected }: NodeProps<FlowNode>) {
  const v = data.view;
  const chip = v.type === 'Profile' ? (v.status === 'VERIFIED' ? '✓ verified' : v.status === 'DEFERRED' ? 'later' : '? candidate') : v.type === 'Contact' ? (v.status === 'Verified' ? '✓ verified' : 'unverified') : v.type === 'Route' ? v.status : v.type === 'Artist' && !v.root ? v.status : null;
  return (
    <div className={cx('w-[212px] rounded-lg border px-2.5 py-1.5 text-left shadow-[var(--shadow)]', v.root ? 'border-2 border-accent-strong bg-accent-soft' : data.highlight ? 'border-2 border-accent-strong bg-surface' : 'border-line-strong bg-surface', selected && 'ring-2 ring-[var(--focus)]')}>
      <Handle id="tl" type="target" position={Position.Left} style={{ opacity: 0 }} />
      <Handle id="sl" type="source" position={Position.Left} style={{ opacity: 0 }} />
      <div className="flex items-center gap-1.5 text-ink">
        <span className={cx('shrink-0', v.root ? 'text-accent-text' : 'text-muted')}>{v.root ? <Star size={14} /> : TYPE_ICON[v.type] ?? <Waypoints size={14} />}</span>
        <span className="truncate text-xs font-semibold" title={v.label}>{v.type === 'Song' ? `“${v.label}”` : v.label}</span>
      </div>
      <div className="mt-0.5 flex items-center justify-between gap-1 text-2xs text-muted">
        <span className="truncate">{v.root ? 'This artist' : v.type}{v.sub ? ` · ${v.sub}` : ''}</span>
        {chip && <span className={cx('shrink-0 rounded px-1', chip.startsWith('✓') ? 'bg-[var(--t-green-bg)] text-[var(--t-green)]' : 'bg-hover')}>{chip}</span>}
      </div>
      {v.demo && <div className="text-3xs font-semibold uppercase tracking-wide text-[var(--t-orange)]">demo data</div>}
      <Handle id="sr" type="source" position={Position.Right} style={{ opacity: 0 }} />
      <Handle id="tr" type="target" position={Position.Right} style={{ opacity: 0 }} />
    </div>
  );
}
const nodeTypes = { entity: EntityNode };

// Artist in the middle: its own profiles, contacts and routes on the left, songs and everything reached
// through them on the right. Long columns wrap so the graph stays readable without zooming far out.
const COL = 264, ROW = 76;
const OWN = new Set(['Profile', 'Contact', 'Route']);
function layout(nodes: ViewNode[], edges: ViewEdge[]): Map<string, { x: number; y: number }> {
  const pos = new Map<string, { x: number; y: number }>();
  const neighbours = new Map<string, string[]>();
  for (const e of edges) { neighbours.set(e.source, [...(neighbours.get(e.source) ?? []), e.target]); neighbours.set(e.target, [...(neighbours.get(e.target) ?? []), e.source]); }
  const bary = (n: ViewNode) => { const ys = (neighbours.get(n.id) ?? []).map(id => pos.get(id)?.y).filter((y): y is number => y !== undefined); return ys.length ? ys.reduce((a, b) => a + b, 0) / ys.length : 0; };
  const byType = (a: ViewNode, b: ViewNode) => TYPE_ORDER.indexOf(a.type) - TYPE_ORDER.indexOf(b.type) || a.label.localeCompare(b.label);
  // place a column group starting at x, growing away from the artist (dir -1 = left, 1 = right); returns the next free x
  const place = (list: ViewNode[], x: number, dir: 1 | -1, maxRows = 10) => {
    const cols = Math.max(1, Math.ceil(list.length / maxRows));
    const rows = Math.ceil(list.length / cols);
    list.forEach((n, i) => { const c = Math.floor(i / rows), r = i % rows, inCol = Math.min(rows, list.length - c * rows); pos.set(n.id, { x: x + dir * c * COL, y: (r - (inCol - 1) / 2) * ROW }); });
    return x + dir * cols * COL;
  };
  const root = nodes.find(n => n.root);
  if (root) pos.set(root.id, { x: 0, y: 0 });
  const rest = nodes.filter(n => !n.root);
  place(rest.filter(n => n.level <= 1 && OWN.has(n.type)).sort(byType), -COL - 40, -1, 12);
  let x = COL + 40;
  const right = rest.filter(n => !(n.level <= 1 && OWN.has(n.type)));
  for (const level of [...new Set(right.map(n => Math.min(n.level, 5)))].sort((a, b) => a - b)) {
    const list = right.filter(n => Math.min(n.level, 5) === level);
    list.sort((a, b) => level <= 1 ? byType(a, b) : bary(a) - bary(b) || byType(a, b));
    x = place(list, x, 1) + 20;
  }
  return pos;
}

export function ConnectionGraph({ caseId, paths = [], focusPathId, onFindConnection, height = 600 }: { caseId: string; paths?: PathLite[]; focusPathId?: string | null; onFindConnection?: () => void; height?: number }) {
  return <ReactFlowProvider><GraphInner caseId={caseId} paths={paths} focusPathId={focusPathId ?? null} onFindConnection={onFindConnection} height={height} /></ReactFlowProvider>;
}

function GraphInner({ caseId, paths, focusPathId, onFindConnection, height }: { caseId: string; paths: PathLite[]; focusPathId: string | null; onFindConnection?: () => void; height: number }) {
  const [depth, setDepth] = useState<'1' | '2'>('1');
  const [expand, setExpand] = useState<string[]>([]);
  const [groups, setGroups] = useState<Set<string>>(new Set(GROUPS.map(g => g.id)));
  const [statuses, setStatuses] = useState<Set<string>>(new Set(STATUSES.map(s => s.id)));
  const [selected, setSelected] = useState<{ kind: 'node' | 'edge'; id: string } | null>(null);
  const [pathId, setPathId] = useState<string | null>(focusPathId);
  useEffect(() => setPathId(focusPathId), [focusPathId]);
  const { data } = useQuery<GraphData | null>('caseGraph', { id: caseId, depth: Number(depth), expand, pathId: pathId ?? undefined });
  const flow = useReactFlow();
  const theme = typeof document !== 'undefined' ? (document.documentElement.dataset.theme as 'light' | 'dark' | undefined) ?? 'system' : 'system';

  const path = paths.find(p => p.id === pathId) ?? null;
  const pathNodes = useMemo(() => new Set(path?.steps.map(s => s.nodeId) ?? []), [path]);
  const view = useMemo(() => {
    if (!data) return null;
    const allowedTypes = new Set(GROUPS.filter(g => groups.has(g.id)).flatMap(g => g.types));
    const keepNode = (n: ViewNode) => n.root || allowedTypes.has(n.type) || pathNodes.has(n.id);
    let nodes = data.nodes.filter(keepNode);
    const ids = new Set(nodes.map(n => n.id));
    const edges = data.edges.filter(e => ids.has(e.source) && ids.has(e.target) && (statuses.has(e.status) || isPathEdge(e)));
    // hide nodes left without any visible relationship (except the artist)
    const linked = new Set(edges.flatMap(e => [e.source, e.target]));
    nodes = nodes.filter(n => n.root || linked.has(n.id));
    return { nodes, edges };
    function isPathEdge(e: ViewEdge) { return pathNodes.has(e.source) && pathNodes.has(e.target); }
  }, [data, groups, statuses, pathNodes]);

  const flowNodes: FlowNode[] = useMemo(() => {
    if (!view) return [];
    const pos = layout(view.nodes, view.edges);
    return view.nodes.map(n => ({ id: n.id, type: 'entity', position: pos.get(n.id) ?? { x: 0, y: 0 }, data: { view: n, highlight: pathNodes.has(n.id) }, selected: selected?.kind === 'node' && selected.id === n.id }));
  }, [view, pathNodes, selected]);
  const flowEdges: Edge[] = useMemo(() => {
    if (!view) return [];
    const level = new Map(view.nodes.map(n => [n.id, n.level]));
    const xOf = new Map(flowNodes.map(n => [n.id, n.position.x]));
    const rootSong = (e: ViewEdge) => e.source === data!.root && view.nodes.find(n => n.id === e.target)?.type === 'Song';
    return view.edges.map(e => {
      const onPath = pathNodes.has(e.source) && pathNodes.has(e.target);
      const [s, t] = (level.get(e.source) ?? 0) <= (level.get(e.target) ?? 0) ? [e.source, e.target] : [e.target, e.source];
      const text = `${e.status === 'verified' ? '✓ ' : ''}${e.label}${e.status === 'possible' ? ' ?' : ''}`;
      const leftward = (xOf.get(t) ?? 0) < (xOf.get(s) ?? 0);
      const near = selected && (selected.kind === 'edge' ? selected.id === e.id : e.source === selected.id || e.target === selected.id);
      return {
        id: e.id, source: s, target: t, sourceHandle: leftward ? 'sl' : 'sr', targetHandle: leftward ? 'tr' : 'tl', animated: onPath, label: onPath || near || !(rootSong(e) || QUIET.has(e.type)) ? text : undefined,
        style: { stroke: onPath ? 'var(--accent-strong)' : e.status === 'verified' ? 'var(--t-green)' : 'var(--faint)', strokeWidth: onPath ? 2.6 : e.status === 'verified' ? 2.2 : 1.3, strokeDasharray: e.status === 'possible' ? '6 4' : undefined },
        labelStyle: { fontSize: 11, fill: 'var(--text-2)' }, labelBgStyle: { fill: 'var(--surface)' }, labelBgPadding: [4, 2] as [number, number], labelBgBorderRadius: 4,
        selected: selected?.kind === 'edge' && selected.id === e.id,
      };
    });
  }, [view, flowNodes, pathNodes, selected, data]);
  // A highlighted path gets the zoom (readable); otherwise the whole graph fits. The fit button always shows everything.
  const focus = useMemo(() => flowNodes.filter(n => pathNodes.has(n.id)).map(n => ({ id: n.id })), [flowNodes, pathNodes]);
  useEffect(() => { const t = setTimeout(() => flow.fitView({ padding: 0.15, maxZoom: 1, duration: 250, ...(focus.length > 1 ? { nodes: focus } : {}) }), 60); return () => clearTimeout(t); }, [flowNodes.length, focus.length, pathId, flow]);

  const reset = () => { setDepth('1'); setExpand([]); setGroups(new Set(GROUPS.map(g => g.id))); setStatuses(new Set(STATUSES.map(s => s.id))); setSelected(null); setPathId(null); };
  const toggle = (set: Set<string>, id: string, fn: (s: Set<string>) => void) => { const n = new Set(set); if (n.has(id)) n.delete(id); else n.add(id); fn(n); };
  const verifiedOnly = statuses.size === 1 && statuses.has('verified');
  const selNode = selected?.kind === 'node' ? data?.nodes.find(n => n.id === selected.id) : null;
  const selEdge = selected?.kind === 'edge' ? data?.edges.find(e => e.id === selected.id) : null;

  return (
    <div className="rounded-lg border border-line bg-surface shadow-[var(--shadow)]">
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <div className="flex flex-wrap gap-1">{GROUPS.map(g => <Chip key={g.id} on={groups.has(g.id)} onClick={() => toggle(groups, g.id, setGroups)}>{g.label}</Chip>)}</div>
        <span className="mx-1 hidden h-5 w-px bg-line sm:block" />
        <div className="flex flex-wrap gap-1">{STATUSES.map(s => <Chip key={s.id} on={statuses.has(s.id)} onClick={() => toggle(statuses, s.id, setStatuses)}>{s.label}</Chip>)}</div>
        <span className="mx-1 hidden h-5 w-px bg-line sm:block" />
        <span className="text-xs text-muted">Depth</span><Segmented options={[{ id: '1', label: '1' }, { id: '2', label: '2' }]} value={depth} onChange={setDepth} />
        <div className="ml-auto flex flex-wrap gap-1.5">
          <Button size="sm" icon={<RotateCcw size={13} />} onClick={reset}>Reset graph</Button>
          <Button size="sm" icon={<ShieldCheck size={13} />} variant={verifiedOnly ? 'dark' : 'secondary'} onClick={() => setStatuses(verifiedOnly ? new Set(STATUSES.map(s => s.id)) : new Set(['verified']))}>Show verified only</Button>
          {onFindConnection && <Button size="sm" variant="primary" icon={<Share2 size={13} />} onClick={onFindConnection}>Find connection</Button>}
        </div>
      </div>
      <div className="grid lg:grid-cols-[minmax(0,1fr)_320px]">
        <div style={{ height: `min(${height}px, 72vh)` }} className="relative min-w-0">
          {!data ? <div className="p-4"><Skeleton className="h-full" /></div> : (
            <ReactFlow nodes={flowNodes} edges={flowEdges} nodeTypes={nodeTypes} fitView minZoom={0.15} maxZoom={1.8} nodesDraggable nodesConnectable={false} elementsSelectable colorMode={theme}
              onNodeClick={(_, n) => setSelected({ kind: 'node', id: n.id })} onEdgeClick={(_, e) => setSelected({ kind: 'edge', id: e.id })} onPaneClick={() => setSelected(null)} proOptions={{ hideAttribution: true }}>
              <Background gap={18} size={1} />
              <Controls showInteractive={false} />
            </ReactFlow>
          )}
          {data && data.hidden.songs > 0 && <p className="pointer-events-none absolute bottom-2 left-14 rounded bg-surface/90 px-2 py-0.5 text-xs text-muted">{data.hidden.songs} more songs not shown (expand the artist)</p>}
        </div>
        <aside className="border-t border-line p-4 text-sm lg:border-l lg:border-t-0">
          {selNode ? <NodeDetails n={selNode} caseId={caseId} expanded={expand.includes(selNode.id)} onExpand={() => setExpand(x => x.includes(selNode.id) ? x.filter(i => i !== selNode.id) : [...x, selNode.id])} />
            : selEdge ? <EdgeDetails e={selEdge} caseId={caseId} data={data!} />
              : <Legend path={path} onClearPath={() => setPathId(null)} />}
        </aside>
      </div>
    </div>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: ReactNode }) {
  return <button type="button" aria-pressed={on} onClick={onClick} className={cx('rounded-full border px-3 py-1 text-xs', on ? 'border-accent-strong bg-accent-soft font-medium text-accent-text' : 'border-line-strong text-muted hover:bg-hover')}>{children}</button>;
}

function Legend({ path, onClearPath }: { path: PathLite | null; onClearPath: () => void }) {
  return (
    <div className="space-y-3">
      {path && (
        <div className="rounded-md border border-accent-line bg-accent-soft p-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-accent-text">Possible connection path</p>
          <p className="mt-1 text-ink">{path.steps.map(s => s.label).join(' → ')}</p>
          <p className="mt-1 text-xs text-muted">{path.steps.length === 2 ? 'The artist’s own verified profile: a direct message, no introduction.' : 'Shared catalogue relationships, not a confirmed personal relationship.'}</p>
          <button type="button" className="mt-1 text-xs underline" onClick={onClearPath}>Clear highlight</button>
        </div>
      )}
      <div>
        <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted">How to read it</p>
        <ul className="space-y-1.5 text-xs text-ink-2">
          <li className="flex items-center gap-2"><span className="h-0.5 w-8 shrink-0 bg-[var(--t-green)]" style={{ height: 2.5 }} />✓ Verified by a person</li>
          <li className="flex items-center gap-2"><span className="h-px w-8 shrink-0 bg-[var(--faint)]" />Discovered: backend catalogue or discovery, with a source</li>
          <li className="flex items-center gap-2"><span className="w-8 shrink-0 border-t-2 border-dashed border-[var(--faint)]" />? Possible: a candidate that needs review</li>
        </ul>
      </div>
      <p className="text-xs text-muted">Click a node or a line to see its evidence and source. Expand a node for more connections (up to two levels around the artist).</p>
    </div>
  );
}

function NodeDetails({ n, caseId, expanded, onExpand }: { n: ViewNode; caseId: string; expanded: boolean; onExpand: () => void }) {
  return (
    <div className="space-y-2">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">{n.root ? 'This artist' : n.type}</p>
      <p className="text-md font-semibold text-ink">{n.type === 'Song' ? `“${n.label}”` : n.label}</p>
      {n.sub && <p className="text-xs text-muted">{n.sub}</p>}
      {n.status && <Badge tone={/verified/i.test(n.status) ? 'green' : 'neutral'}>{n.status}</Badge>}
      {n.demo && <p className="text-xs font-medium text-[var(--t-orange)]">Demo data (fictional)</p>}
      <div className="flex flex-wrap gap-1.5 pt-1">
        {!n.root && ['Song', 'Artist', 'Person', 'Label', 'Distributor', 'Collaborator'].includes(n.type) && <Button size="sm" icon={expanded ? <Minus size={13} /> : <Plus size={13} />} onClick={onExpand}>{expanded ? 'Collapse' : 'Expand'}</Button>}
        {n.type === 'Artist' && !n.root && n.refId && <Link to={`/artists/${n.refId}?tab=graph`}><Button size="sm">Open artist</Button></Link>}
        {n.type === 'Profile' && n.url && <ProfileLink url={n.url} demo={!!n.demo} profileId={n.refId ?? undefined} small />}
        {n.type === 'Route' && <Link to={`/artists/${caseId}?tab=routes`}><Button size="sm">Open routes</Button></Link>}
      </div>
    </div>
  );
}

function EdgeDetails({ e, caseId, data }: { e: ViewEdge; caseId: string; data: GraphData }) {
  const { open } = useActions();
  const { can } = useApp();
  void can;
  const name = (id: string) => data.nodes.find(n => n.id === id)?.label ?? id;
  const personEdge = (e.type === 'PERSON_CONNECTED_TO_ARTIST' && e.status !== 'verified') || (/CREDITED|PERFORMED|COMPOSED|PRODUCED/.test(e.type) && e.source !== data.root && e.target !== data.root);
  return (
    <div className="space-y-2">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">Relationship</p>
      <p className="text-ink"><b>{name(e.source)}</b> → {e.label} → <b>{name(e.target)}</b></p>
      <p className="text-xs text-muted">{e.type.replace(/_/g, ' ').toLowerCase()}</p>
      <Badge tone={e.status === 'verified' ? 'green' : e.status === 'possible' ? 'orange' : 'neutral'}>{e.status === 'verified' ? '✓ Verified by a person' : e.status === 'possible' ? '? Possible: needs review' : 'Discovered with a source'}</Badge>
      <div><p className="text-xs font-medium text-muted">Evidence</p><p className="text-ink-2">{e.evidence}</p></div>
      <div><p className="text-xs font-medium text-muted">Source</p><p className="text-ink-2">{e.sourceLabel} · {e.sourceType}{e.discoveredAt ? ` · found ${fmtDate(e.discoveredAt)}` : ''}</p>{e.sourceUrl && <a href={e.sourceUrl} target="_blank" rel="noopener noreferrer" className="mono inline-flex items-center gap-1 break-all text-xs underline">{e.sourceUrl}<ExternalLink size={11} /></a>}</div>
      {e.verifiedAt && <p className="text-xs text-muted">Verified by {e.verifiedBy} on {fmtDate(e.verifiedAt)}</p>}
      <p className="text-xs text-muted">Confidence {e.confidence}%</p>
      {personEdge && (
        <div className="rounded-md border border-line bg-surface-2 p-2 text-xs text-ink-2">
          Being credited on the same song does not prove that two people know each other.
          <Button size="sm" className="mt-1.5" onClick={() => open('verifyRelationship', { caseId, preset: { edgeId: e.id, label: `${name(e.source)} → ${name(e.target)}` } })}>Confirm a real relationship…</Button>
        </div>
      )}
    </div>
  );
}

export function GraphEmpty() { return <Empty title="No graph yet." text="The graph appears when the artist has songs, credits or profiles." />; }
