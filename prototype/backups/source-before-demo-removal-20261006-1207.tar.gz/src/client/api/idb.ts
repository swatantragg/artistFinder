// IndexedDB persistence for the standalone build (no server). One object store per collection.
import type { Store } from '../../domain/engine';
import { COLLECTIONS, type Dirty, type Snapshot } from '../../domain/model';

const DB_NAME = 'gamplify-case-os';
const VERSION = 1;

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => { for (const c of COLLECTIONS) if (!req.result.objectStoreNames.contains(c)) req.result.createObjectStore(c, { keyPath: 'id' }); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
const done = (tx: IDBTransaction) => new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error ?? new Error('Browser storage write aborted')); });

export class IdbStore implements Store {
  private db: Promise<IDBDatabase> | null = null;
  private get conn() { return (this.db ??= open()); }

  async load(): Promise<Snapshot | null> {
    const db = await this.conn;
    const tx = db.transaction(COLLECTIONS, 'readonly');
    const snap: Snapshot = {};
    let any = false;
    await Promise.all(COLLECTIONS.map(c => new Promise<void>((resolve, reject) => {
      const r = tx.objectStore(c).getAll();
      r.onsuccess = () => { (snap as Record<string, unknown[]>)[c] = r.result; if (r.result.length) any = true; resolve(); };
      r.onerror = () => reject(r.error);
    })));
    return any ? snap : null;
  }
  async save(dirty: Dirty): Promise<void> {
    const names = COLLECTIONS.filter(c => dirty.created[c]?.length || dirty.updated[c]?.length);
    if (!names.length) return;
    const db = await this.conn;
    const tx = db.transaction(names, 'readwrite');
    for (const c of names) {
      const s = tx.objectStore(c);
      for (const row of [...(dirty.created[c] ?? []), ...(dirty.updated[c] ?? [])]) s.put(row);
    }
    await done(tx);
  }
  async replace(snapshot: Snapshot): Promise<void> {
    const db = await this.conn;
    const tx = db.transaction(COLLECTIONS, 'readwrite');
    for (const c of COLLECTIONS) {
      const s = tx.objectStore(c);
      s.clear();
      for (const row of (snapshot[c] ?? []) as unknown[]) s.put(row);
    }
    await done(tx);
  }
}
