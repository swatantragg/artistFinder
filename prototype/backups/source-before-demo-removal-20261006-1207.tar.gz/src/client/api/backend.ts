// Service layer used by every screen. Two implementations with the same contract:
//  - server: the Express API backed by PostgreSQL (npm run dev / npm start)
//  - browser: the same domain engine running in the page, saved to IndexedDB (standalone file, or when no API is running)
import type { CommandResult } from '../../domain/commands';
import type { Engine, ImportJob } from '../../domain/engine';

export type ImportStep = 'Uploading' | 'Validating' | 'Matching' | 'Detecting changes' | 'Updating cases' | 'Creating tasks' | 'Complete';
export interface UploadOptions { importType: 'Full' | 'Incremental'; exportDate: string; source: string }
export type ImportJobView = Omit<ImportJob, 'userId'>;

export interface Backend {
  kind: 'server' | 'browser';
  query<T>(name: string, params: object, userId: string): Promise<T>;
  command(name: string, params: object, userId: string): Promise<CommandResult>;
  /** Starts a background import and reports the job until it is finished (v2 §39). */
  upload(file: { name: string; bytes: Uint8Array }, opts: UploadOptions, userId: string, onJob: (j: ImportJobView) => void): Promise<ImportJobView>;
  reset(mode: 'demo' | 'empty', userId: string): Promise<void>;
}
const finished = (j: ImportJobView) => j.status === 'COMPLETED' || j.status === 'FAILED';
const wait = (ms: number) => new Promise(r => setTimeout(r, ms));

export class ApiError extends Error {}

class ServerBackend implements Backend {
  kind = 'server' as const;
  private async post<T>(url: string, body: object, userId: string): Promise<T> {
    let res: Response;
    try {
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-user-id': userId }, body: JSON.stringify(body) });
    } catch {
      throw new ApiError('Cannot reach the server. Check that "npm run dev" is still running.');
    }
    const data = await res.json().catch(() => ({ error: `Server error ${res.status}` }));
    if (!res.ok) throw new ApiError(data.error ?? `Server error ${res.status}`);
    return data as T;
  }
  query<T>(name: string, params: object, userId: string) { return this.post<T>(`/api/query/${name}`, params, userId); }
  command(name: string, params: object, userId: string) { return this.post<CommandResult>(`/api/command/${name}`, params, userId); }
  async reset(mode: 'demo' | 'empty', userId: string) { await this.post('/api/admin/reset', { mode }, userId); }
  async upload(file: { name: string; bytes: Uint8Array }, opts: UploadOptions, userId: string, onJob: (j: ImportJobView) => void): Promise<ImportJobView> {
    const qs = new URLSearchParams({ filename: file.name, importType: opts.importType, exportDate: opts.exportDate, source: opts.source });
    let res: Response;
    try { res = await fetch(`/api/import?${qs}`, { method: 'POST', headers: { 'content-type': 'application/octet-stream', 'x-user-id': userId }, body: file.bytes as BodyInit }); }
    catch { throw new ApiError('Cannot reach the server. Check that "npm run dev" is still running.'); }
    const d = await res.json().catch(() => ({}));
    if (!res.ok || !d.job) throw new ApiError(d.error ?? `Upload failed (${res.status})`);
    let job: ImportJobView = d.job;
    onJob(job);
    while (!finished(job)) {
      await wait(500);
      const r = await fetch(`/api/import/jobs/${encodeURIComponent(job.id)}`, { headers: { 'x-user-id': userId } }).catch(() => null);
      if (r?.ok) { job = await r.json(); onJob(job); }
    }
    return job;
  }
}

class BrowserBackend implements Backend {
  kind = 'browser' as const;
  constructor(private engine: Engine) {}
  async query<T>(name: string, params: object, userId: string) { return this.engine.query(name, userId, params as Record<string, unknown>) as T; }
  command(name: string, params: object, userId: string) { return this.engine.command(name, userId, params as Record<string, unknown>); }
  async reset(mode: 'demo' | 'empty') { await this.engine.reset(mode); }
  async upload(file: { name: string; bytes: Uint8Array }, opts: UploadOptions, userId: string, onJob: (j: ImportJobView) => void): Promise<ImportJobView> {
    let sheets: { name: string; rows: unknown[][] }[] | undefined;
    if (/\.xlsx?$/i.test(file.name)) {
      const XLSX = await import('xlsx');
      const wb = XLSX.read(file.bytes, { type: 'array' });
      sheets = wb.SheetNames.map(name => ({ name, rows: XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[name], { header: 1, defval: '', raw: false }) }));
    }
    const start = this.engine.startImport({ filename: file.name, bytes: file.bytes, sheets, ...opts }, userId);
    let job: ImportJobView = { ...start };
    onJob(job);
    while (!finished(job)) { await wait(150); job = { ...this.engine.importJob(start.id)! }; onJob(job); }
    return job;
  }
}


/** Use the API when it answers; otherwise run the engine in the page. */
export async function connect(onStatus: (s: string) => void): Promise<Backend> {
  if (!__STANDALONE__) {
    // The API may still be loading the workspace from PostgreSQL: keep trying for a few seconds before falling back.
    for (let attempt = 0; attempt < 12; attempt++) {
      try {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), 2000);
        const res = await fetch('/api/health', { signal: ctl.signal });
        clearTimeout(timer);
        if (res.ok && (await res.json()).mode === 'server') return new ServerBackend();
      } catch { /* not up yet */ }
      onStatus('Waiting for the API server… (npm run dev starts it)');
      await new Promise(r => setTimeout(r, 1000));
    }
  }
  onStatus('Preparing the demo workspace in this browser…');
  const [{ Engine }, { IdbStore }] = await Promise.all([import('../../domain/engine'), import('./idb')]);
  const engine = new Engine(new IdbStore());
  try {
    await engine.init();
  } catch {
    // Storage blocked (private window, preview): keep working in memory for this visit.
    const mem = { load: async () => null, save: async () => {}, replace: async () => {} };
    const e2 = new Engine(mem);
    await e2.init();
    return new BrowserBackend(e2);
  }
  return new BrowserBackend(engine);
}
