// Entry: connect to the API (or the in-browser engine), then render the app.
import { StrictMode, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter, Navigate, Route, Routes, useLocation, useParams } from 'react-router-dom';
import { connect, type Backend } from './api/backend';
import { ActionHost } from './components/actions';
import { PreviewHost } from './components/discovery/bits';
import { Layout } from './components/Layout';
import { Empty } from './components/ui';
import { AppProvider } from './lib/app';
import { AuditPage, ReportsPage, SettingsPage, applyStoredTheme } from './pages/Admin';
import Artists from './pages/Artists';
import Dashboard from './pages/Dashboard';
import Deduplicate from './pages/Deduplicate';
import Dossier from './pages/dossier/Dossier';
import ImportResult from './pages/ImportResult';
import Imports from './pages/Imports';
import { ResearchPage, RoutesPage } from './pages/Overviews';
import Queue from './pages/Queue';
import VerifiedArtists from './pages/VerifiedArtists';
import './styles.css';

/** Old links (bookmarks, notifications) keep working: they open the same thing in the artist-centric layout. */
function ToArtist({ tab }: { tab?: string }) {
  const { id = '' } = useParams();
  const { search } = useLocation();
  const q = new URLSearchParams(search);
  if (tab) q.set('tab', tab);
  return <Navigate to={`/artists/${id}${q.toString() ? `?${q}` : ''}`} replace />;
}

applyStoredTheme();

function Boot() {
  const [backend, setBackend] = useState<Backend | null>(null);
  const [status, setStatus] = useState('Connecting…');
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { connect(setStatus).then(setBackend).catch(e => setError(String(e?.message ?? e))); }, []);
  if (error) return <Splash text={`Could not start: ${error}`} />;
  if (!backend) return <Splash text={status} />;
  return (
    <AppProvider backend={backend}>
      <HashRouter>
        <ActionHost>
          <PreviewHost>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/artists" element={<Artists />} />
              <Route path="/artists/:id" element={<Dossier />} />
              <Route path="/deduplicate" element={<Deduplicate />} />
              <Route path="/verified" element={<VerifiedArtists />} />
              <Route path="/imports" element={<Imports />} />
              <Route path="/imports/:id" element={<ImportResult />} />
              <Route path="/settings" element={<SettingsPage />} />
              {/* Tools kept inside Settings → More tools */}
              <Route path="/queue" element={<Queue />} />
              <Route path="/routes" element={<RoutesPage />} />
              <Route path="/research" element={<ResearchPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/audit" element={<AuditPage />} />
              {/* v1 addresses */}
              <Route path="/cases" element={<Navigate to="/artists" replace />} />
              <Route path="/cases/:id" element={<ToArtist />} />
              <Route path="/discovery" element={<Navigate to="/artists" replace />} />
              <Route path="/discovery/:id" element={<ToArtist tab="evidence" />} />
              <Route path="/identity" element={<Navigate to="/deduplicate" replace />} />
              <Route path="/reopened" element={<Navigate to="/artists?status=REOPENED" replace />} />
              <Route path="/claims" element={<Navigate to="/verified" replace />} />
              <Route path="*" element={<Empty title="Page not found." text="Use the menu on the left." />} />
            </Routes>
          </Layout>
          </PreviewHost>
        </ActionHost>
      </HashRouter>
    </AppProvider>
  );
}

function Splash({ text }: { text: string }) {
  return (
    <div className="flex h-full items-center justify-center bg-bg">
      <div className="text-center">
        <div className="brand-mark mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl text-md font-bold">AF</div>
        <p className="text-sm text-muted">{text}</p>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(<StrictMode><Boot /></StrictMode>);
