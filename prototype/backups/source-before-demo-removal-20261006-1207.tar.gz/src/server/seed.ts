// Seeds PostgreSQL with the fictional demo workspace.
//   npm run db:seed    seed only when the database is empty
//   npm run db:reset   replace everything with a fresh demo
import { Engine } from '../domain/engine';
import { PrismaStore } from './store';

const store = new PrismaStore();
const engine = new Engine(store);
const t = Date.now();
try {
  if (process.argv.includes('--reset')) {
    await engine.reset('demo');
    console.log('Database reset to the fictional demo workspace.');
  } else {
    const how = await engine.init();
    console.log(how === 'seeded' ? 'Seeded the fictional demo workspace.' : 'Database already has data. Use "npm run db:reset" to start again.');
  }
  console.log(await store.counts(), `${Date.now() - t} ms`);
} finally {
  await store.db.$disconnect();
}
