// Evidence for each candidate profile: why it was found, what matches the catalogue, what conflicts.
// The score is a "discovery evidence score" (how much catalogue evidence points here). It is never an identity confidence.
import type { DiscoveryStrength, EvidenceKind, Platform } from '../constants';
import type { ProfileTrack } from '../types';
import { foldText, handleKey, hasPhrase } from './normalize';
import type { CaseFacts } from './queries';

export interface EvidenceItem { kind: EvidenceKind; polarity: 'match' | 'conflict'; detail: string; weight: number; hard?: boolean }
export interface ProfileInput {
  normalizedUrl: string;
  platform: Platform;
  displayName: string;
  username: string | null;
  title: string;
  description: string;
  location: string | null;
  language: string | null;
  links: string[];               // normalized
  tracks: ProfileTrack[];
}
export interface Scored { items: EvidenceItem[]; score: number; strength: DiscoveryStrength; matchedSongs: string[]; otherCaseId: string | null; specific: boolean }

const ROLE_WORDS: Record<string, RegExp> = {
  Singer: /\b(singer|vocalist|playback)\b/, Composer: /\b(composer|music director)\b/, Lyricist: /\b(lyricist|lyrics|words for)\b/,
  Producer: /\b(producer|produced|beatmaker)\b/, Performer: /\b(artist|performer|musician)\b/,
};
const OTHER_PROFESSION = /\b(actor|actress|model|vlogger|photographer|chef|cricketer|cricket|fitness|software|engineer|coach|real estate|influencer)\b/;

export function scoreProfile(p: ProfileInput, f: CaseFacts, linkedFromStrong: string[] = []): Scored {
  const items: EvidenceItem[] = [];
  const add = (kind: EvidenceKind, detail: string, weight: number, polarity: 'match' | 'conflict' = 'match', hard = false) => items.push({ kind, detail, weight, polarity, hard });
  const nameHay = foldText(`${p.displayName} ${p.title}`);
  const hay = foldText([p.title, p.displayName, p.username, p.description, ...p.tracks.map(t => t.title)].join(' '));
  // name
  if (hasPhrase(nameHay, f.name)) add('Name match', `Name matches “${f.name}”`, 18);
  else {
    const alias = f.aliases.find(a => hasPhrase(nameHay, a));
    if (alias) add('Alias match', `Alias “${alias}” matches`, 12);
    else {
      const parts = f.name.split(/\s+/).filter(x => x.length >= 3);
      if (parts.some(x => hasPhrase(nameHay, x)) || (p.username && parts.some(x => handleKey(p.username).includes(x.toLowerCase())))) add('Partial name match', `Part of the name appears (“${p.displayName}”)`, 6);
      else add('Name differs', `Display name is “${p.displayName}”`, -4, 'conflict');
    }
  }
  // songs and ISRCs
  const matchedSongs: string[] = [];
  for (const s of f.songs) if (s.title.length >= 5 && hasPhrase(hay, s.title) && !matchedSongs.includes(s.title)) matchedSongs.push(s.title);
  for (const t of matchedSongs.slice(0, 3)) add('Song match', `Song “${t}” found`, 10);
  const isrcs = new Map(f.songs.filter(s => s.isrc).map(s => [s.isrc.toUpperCase(), s.title]));
  const isrcHit = p.tracks.find(t => t.isrc && isrcs.has(t.isrc.toUpperCase()));
  if (isrcHit) { add('ISRC match', `ISRC ${isrcHit.isrc} matches “${isrcs.get(isrcHit.isrc!.toUpperCase())}”`, 30); if (!matchedSongs.includes(isrcs.get(isrcHit.isrc!.toUpperCase())!)) matchedSongs.push(isrcs.get(isrcHit.isrc!.toUpperCase())!); }
  if (matchedSongs.length >= 3) add('Catalogue match', `${matchedSongs.length} catalogue songs listed`, 10);
  // label, distributor, role, collaborators
  const label = f.labels.find(l => hasPhrase(hay, l));
  if (label) add('Label match', `Same label: ${label}`, 10);
  const dist = f.distributors.find(d => hasPhrase(hay, d));
  if (dist) add('Distributor match', `Same distributor: ${dist}`, 4);
  const role = f.roles.find(r => ROLE_WORDS[r]?.test(hay));
  if (role) add('Role match', `${role} role matches`, 6);
  const collabs = f.collaborators.filter(c => hasPhrase(hay, c.name)).slice(0, 2);
  for (const c of collabs) add('Collaborator match', `Mentions collaborator ${c.name}`, 8);
  // language
  if (f.language && p.language) {
    if (p.language.toLowerCase() === f.language.toLowerCase()) add('Language match', `Language: ${p.language}`, 3);
    else add('Different language', `Profile language ${p.language}, catalogue ${f.language}`, -4, 'conflict');
  }
  // cross-platform: linked from a strong profile, or an official website listing it
  for (const from of linkedFromStrong.slice(0, 1)) add(from.startsWith('website:') ? 'Official website match' : 'Cross-platform match', from.startsWith('website:') ? `Listed on the artist's website (${from.slice(8)})` : `Linked from ${from}`, 12);
  // conflicts that make it a different person
  const specific = matchedSongs.length > 0 || !!isrcHit || !!label || collabs.length > 0;
  const profession = OTHER_PROFESSION.exec(hay)?.[1];
  if (profession && !specific) add('Different profession', `Profile describes ${/^[aeiou]/.test(profession) ? 'an' : 'a'} ${profession}, with no music from the catalogue`, -25, 'conflict', true);
  let otherCaseId: string | null = null;
  for (const o of f.otherSameName) {
    const hits = o.songTitles.filter(t => t.length >= 5 && hasPhrase(hay, t));
    const isrcOther = p.tracks.some(t => t.isrc && o.isrcs.includes(t.isrc));
    if ((hits.length || isrcOther) && !specific) {
      otherCaseId = o.caseId;
      add('Songs of another artist', `Songs match ${o.name} (${o.artistId ?? o.caseId}), a different case with the same name${hits[0] ? `: “${hits[0]}”` : ''}`, -30, 'conflict', true);
      break;
    }
  }
  const rejected = f.rejected.get(p.normalizedUrl);
  if (rejected) add('Previously rejected', rejected, -30, 'conflict', true);
  const score = Math.max(0, Math.min(100, items.reduce((n, x) => n + x.weight, 0)));
  const hard = items.some(x => x.hard);
  const strongEvidence = !!isrcHit || matchedSongs.length >= 2 || (matchedSongs.length >= 1 && (!!label || collabs.length > 0)) || (linkedFromStrong.length > 0 && specific);
  const strength: DiscoveryStrength = hard ? 'WEAK' : score >= 60 && strongEvidence ? 'STRONG' : score >= 30 ? 'POSSIBLE' : 'WEAK';
  return { items, score, strength, matchedSongs, otherCaseId, specific };
}

/** Location conflicts are only visible across a candidate group (one person, several profiles). */
export function locationConflicts(members: { id: string; platform: string; location: string | null }[]): Map<string, string> {
  const out = new Map<string, string>();
  const located = members.filter(x => x.location);
  const counts = new Map<string, number>();
  for (const x of located) counts.set(x.location!, (counts.get(x.location!) ?? 0) + 1);
  if (counts.size < 2) return out;
  const main = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
  for (const x of located) if (x.location !== main) out.set(x.id, `Different city: ${x.location} on ${x.platform}, ${main} on other profiles`);
  return out;
}

/** Union-find grouping of profiles that probably belong to one person: cross-links, same handle, shared songs, same other artist. */
export function groupProfiles<T extends { id: string; normalizedUrl: string; username: string | null; links: string[]; matchedSongs: string[]; otherCaseId: string | null; evidenceScore: number; verificationStatus: string }>(list: T[]): Map<string, string> {
  const parent = new Map(list.map(p => [p.id, p.id]));
  const find = (x: string): string => { let r = x; while (parent.get(r) !== r) r = parent.get(r)!; parent.set(x, r); return r; };
  const union = (a: string, b: string) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
  const byUrl = new Map(list.map(p => [p.normalizedUrl, p.id]));
  for (const p of list) for (const l of p.links) { const q = byUrl.get(l); if (q && q !== p.id) union(p.id, q); }
  const byHandle = new Map<string, string>();
  for (const p of list) { const h = handleKey(p.username); if (h.length >= 6) { const q = byHandle.get(h); if (q) union(p.id, q); else byHandle.set(h, p.id); } }
  const bySong = new Map<string, string>();
  for (const p of list) if (!p.otherCaseId) for (const s of p.matchedSongs) { const q = bySong.get(s); if (q) union(p.id, q); else bySong.set(s, p.id); }
  const byOther = new Map<string, string>();
  for (const p of list) if (p.otherCaseId) { const q = byOther.get(p.otherCaseId); if (q) union(p.id, q); else byOther.set(p.otherCaseId, p.id); }
  // Group labels: the group holding a verified profile first, then by best evidence.
  const groups = new Map<string, T[]>();
  for (const p of list) { const r = find(p.id); groups.set(r, [...(groups.get(r) ?? []), p]); }
  const ordered = [...groups.values()].sort((a, b) => Number(b.some(x => x.verificationStatus === 'VERIFIED')) - Number(a.some(x => x.verificationStatus === 'VERIFIED')) || Math.max(...b.map(x => x.evidenceScore)) - Math.max(...a.map(x => x.evidenceScore)));
  const out = new Map<string, string>();
  ordered.forEach((g, i) => { const label = groupLetter(i); for (const p of g) out.set(p.id, label); });
  return out;
}
export const groupLetter = (i: number) => (i < 26 ? String.fromCharCode(65 + i) : `Z${i - 25}`);
