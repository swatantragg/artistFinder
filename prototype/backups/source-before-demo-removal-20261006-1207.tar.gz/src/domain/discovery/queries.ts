// Step 1 of Find Artist: read everything the catalogue knows about the artist, then turn it into search queries.
// Queries combine the name with songs, ISRCs, labels, roles, platforms and collaborators, never the name alone.
import type { DiscoveryMode, Platform } from '../constants';
import type { Model } from '../model';
import type { QueryKind } from '../types';
import { nameKey } from '../util';
import { normalizeProfileUrl, normalizeQuery } from './normalize';

export interface SongFact { trackId: string; title: string; isrc: string; label: string; distributor: string; releaseDate: string; roles: string[]; isNew: boolean; collaborators: string[] }
export interface CollabFact { key: string; name: string; caseId: string | null; roles: string[]; songs: string[]; verifiedProfiles: number; verifiedContacts: number; isNew: boolean }
export interface OtherArtist { caseId: string; name: string; artistId: string | null; songTitles: string[]; isrcs: string[] }
export interface CaseFacts {
  caseId: string;
  name: string;
  aliases: string[];
  artistIds: string[];
  roles: string[];
  language: string | null;
  songs: SongFact[];
  labels: string[];
  distributors: string[];
  collaborators: CollabFact[];
  profileUrls: string[];
  otherSameName: OtherArtist[];
  rejected: Map<string, string>;        // normalized URL -> why it was rejected before
  verifiedUrls: Map<string, string>;    // normalized URL -> verified profile id
  stats: { songs: number; credits: number; collaborators: number; isrcs: number; labels: number; releases: number };
}

export interface SearchRequest {
  query: string;
  kind: QueryKind;
  priority: number;
  platform?: Platform;
  isrc?: string;
  subject: 'artist' | 'collaborator';
  subjectName: string;
  subjectKey: string;                    // collaborator key (case id or name key)
}

const ROLE_WORD: Record<string, string> = { Singer: 'singer', Performer: 'artist', Composer: 'composer', Lyricist: 'lyricist', Producer: 'producer', Other: 'music' };
const PLATFORM_QUERIES: { word: string; site: string; platform: Platform }[] = [
  { word: 'Instagram', site: 'instagram.com', platform: 'Instagram' },
  { word: 'YouTube', site: 'youtube.com', platform: 'YouTube' },
  { word: 'Spotify', site: 'open.spotify.com', platform: 'Spotify' },
  { word: 'Facebook', site: 'facebook.com', platform: 'Facebook' },
  { word: 'SoundCloud', site: 'soundcloud.com', platform: 'SoundCloud' },
];

export function buildFacts(m: Model, caseId: string, focusTrackIds: string[] = []): CaseFacts {
  const c = m.must('cases', caseId);
  const fam = new Set(m.family(caseId));
  const focus = new Set(focusTrackIds);
  const songs: SongFact[] = [];
  const collabs = new Map<string, CollabFact>();
  let credits = 0;
  const releases = new Set<string>();
  for (const tid of m.trackIdsOfCase(caseId)) {
    const t = m.get('tracks', tid);
    if (!t) continue;
    if (t.releaseId) releases.add(t.releaseId);
    const all = m.creditsOfTrack(tid).filter(cr => cr.status === 'Active');
    credits += all.length;
    const mine = all.filter(cr => cr.caseId && fam.has(cr.caseId));
    const others = all.filter(cr => !(cr.caseId && fam.has(cr.caseId)));
    songs.push({ trackId: tid, title: t.title, isrc: t.isrc, label: t.label, distributor: t.distributor, releaseDate: t.releaseDate, roles: mine.map(x => x.role), isNew: focus.has(tid), collaborators: others.map(o => o.personName) });
    for (const o of others) {
      const key = o.caseId ? m.canonical(o.caseId) : `name:${nameKey(o.personName)}`;
      const x = collabs.get(key) ?? { key, name: o.caseId ? m.get('cases', m.canonical(o.caseId))?.canonicalName ?? o.personName : o.personName, caseId: o.caseId ? m.canonical(o.caseId) : null, roles: [], songs: [], verifiedProfiles: 0, verifiedContacts: 0, isNew: false };
      if (!x.roles.includes(o.role)) x.roles.push(o.role);
      if (!x.songs.includes(t.title)) x.songs.push(t.title);
      if (focus.has(tid)) x.isNew = true;
      collabs.set(key, x);
    }
  }
  for (const x of collabs.values()) {
    if (x.caseId) {
      x.verifiedProfiles = m.byCase('verifiedProfiles', x.caseId).filter(v => v.verificationStatus === 'VERIFIED').length;
      x.verifiedContacts = m.contactsFor(x.caseId).filter(k => k.verified).length;
    } else x.verifiedContacts = m.contactsNamed(x.name).filter(k => k.verified).length;
  }
  songs.sort((a, b) => Number(b.isNew) - Number(a.isNew) || b.collaborators.length - a.collaborators.length || (b.releaseDate || '').localeCompare(a.releaseDate || ''));
  const roles = [...new Set(songs.flatMap(s => s.roles))];
  // Same or similar names elsewhere in the catalogue: their songs help tell the people apart.
  const otherSameName: OtherArtist[] = [];
  for (const o of [...m.casesNamed(c.canonicalName), ...m.casesSimilar(c.canonicalName)]) {
    if (o.id === caseId || fam.has(o.id) || otherSameName.some(x => x.caseId === o.id)) continue;
    const tracks = m.trackIdsOfCase(o.id).map(id => m.get('tracks', id)!).filter(Boolean);
    otherSameName.push({ caseId: o.id, name: o.canonicalName, artistId: o.backendProfileIds[0] ?? null, songTitles: tracks.map(t => t.title), isrcs: tracks.map(t => t.isrc).filter(Boolean) });
  }
  const rejected = new Map<string, string>();
  for (const p of m.byCase('profiles', caseId)) if (p.verificationStatus === 'REJECTED') rejected.set(p.normalizedUrl, p.rejectionReason ?? 'Rejected before');
  for (const r of m.byCase('routes', caseId)) if (r.sourceUrl && r.state === 'Rejected') { const n = normalizeProfileUrl(r.sourceUrl); if (n) rejected.set(n.normalized, `Route ${r.id} rejected: ${r.rejectionReason ?? 'wrong person'}`); }
  const verifiedUrls = new Map<string, string>();
  for (const v of m.byCase('verifiedProfiles', caseId)) if (v.verificationStatus === 'VERIFIED') { const n = normalizeProfileUrl(v.url); if (n) verifiedUrls.set(n.normalized, v.id); }
  return {
    caseId, name: c.canonicalName, aliases: c.aliases, artistIds: c.backendProfileIds, roles, language: c.language, songs,
    labels: [...new Set(songs.map(s => s.label).filter(Boolean))], distributors: [...new Set(songs.map(s => s.distributor).filter(Boolean))],
    collaborators: [...collabs.values()].sort((a, b) => Number(b.isNew) - Number(a.isNew) || b.songs.length - a.songs.length || a.name.localeCompare(b.name)),
    profileUrls: c.profileUrls, otherSameName, rejected, verifiedUrls,
    stats: { songs: songs.length, credits, collaborators: collabs.size, isrcs: songs.filter(s => s.isrc).length, labels: new Set(songs.map(s => s.label).filter(Boolean)).size, releases: releases.size },
  };
}

const q = (s: string) => `"${s.replace(/"/g, '')}"`;
const LIMITS: Record<DiscoveryMode | 'bulk', { artist: number; collab: number }> = {
  full: { artist: 22, collab: 6 }, refresh: { artist: 22, collab: 6 }, targeted: { artist: 8, collab: 4 }, bulk: { artist: 11, collab: 2 },
};

/** Artist queries (web search and supported APIs). Deduplicated and capped to control search cost. */
export function artistQueries(f: CaseFacts, mode: DiscoveryMode, bulk = false): SearchRequest[] {
  const out: SearchRequest[] = [];
  const add = (query: string, kind: QueryKind, priority: number, extra: Partial<SearchRequest> = {}) => out.push({ query, kind, priority, subject: 'artist', subjectName: f.name, subjectKey: f.caseId, ...extra });
  const name = q(f.name);
  const role = ROLE_WORD[f.roles[0] ?? 'Singer'] ?? 'singer';
  const songs = f.songs.filter(s => s.title.length >= 4);
  if (mode === 'targeted') {
    const fresh = songs.filter(s => s.isNew);
    for (const s of fresh.slice(0, 3)) {
      add(`${name} ${q(s.title)}`, 'song', 1);
      for (const c of s.collaborators.slice(0, 2)) add(`${q(s.title)} ${q(c)}`, 'song', 2);
      if (s.isrc) add(q(s.isrc), 'isrc', 3, { isrc: s.isrc });
    }
    for (const l of [...new Set(fresh.map(s => s.label))].filter(Boolean).slice(0, 1)) add(`${name} ${q(l)}`, 'label', 4);
    for (const c of f.collaborators.filter(x => x.isNew).slice(0, 2)) add(`${q(c.name)} ${name}`, 'collaborator', 5);
  } else {
    add(name, 'name', 1);
    add(`${name} ${role}`, 'role', 2);
    if (songs[0]) add(`${name} ${q(songs[0].title)}`, 'song', 3);
    if (f.labels[0]) add(`${name} ${q(f.labels[0])}`, 'label', 4);
    if (songs.find(s => s.isrc)) { const s = songs.find(x => x.isrc)!; add(q(s.isrc), 'isrc', 5, { isrc: s.isrc }); }
    for (const p of PLATFORM_QUERIES.slice(0, 4)) add(`${name} ${p.word}`, 'platform', 6, { platform: p.platform });
    for (const p of PLATFORM_QUERIES.filter(x => x.platform !== 'Spotify')) add(`${name} site:${p.site}`, 'site', 7, { platform: p.platform });
    for (const s of songs.slice(1, 3)) add(`${name} ${q(s.title)}`, 'song', 8);
    for (const s of songs.filter(x => x.isrc).slice(1, 2)) add(q(s.isrc), 'isrc', 9, { isrc: s.isrc });
    if (songs[0]) add(q(songs[0].title), 'song', 10);
    if (f.distributors[0]) add(`${name} ${q(f.distributors[0])}`, 'distributor', 11);
    for (const a of f.aliases.slice(0, 2)) add(`${q(a)} ${role}`, 'alias', 12);
  }
  return dedupe(out).sort((a, b) => a.priority - b.priority).slice(0, LIMITS[bulk ? 'bulk' : mode].artist);
}

/** Collaborator queries: look up the people credited with the artist, unless they are already verified. */
export function collaboratorQueries(f: CaseFacts, mode: DiscoveryMode, bulk = false): SearchRequest[] {
  const out: SearchRequest[] = [];
  const pool = f.collaborators.filter(c => (mode === 'targeted' ? c.isNew : true) && c.verifiedProfiles === 0).slice(0, 3);
  const fresh = new Set(f.songs.filter(s => s.isNew).map(s => s.title));
  for (const c of pool) {
    const base = { kind: 'collaborator' as QueryKind, subject: 'collaborator' as const, subjectName: c.name, subjectKey: c.caseId ?? c.key };
    const song = mode === 'targeted' ? c.songs.find(t => fresh.has(t)) : c.songs[0];
    if (song) out.push({ ...base, query: `${q(c.name)} ${q(song)}`, priority: 1 });
    out.push({ ...base, query: `${q(c.name)} ${q(f.name)}`, priority: 2 });
    out.push({ ...base, query: `${q(c.name)} ${ROLE_WORD[c.roles[0] ?? 'Other'] ?? 'music'}`, priority: 3 });
  }
  return dedupe(out).sort((a, b) => a.priority - b.priority).slice(0, LIMITS[bulk ? 'bulk' : mode].collab);
}

function dedupe(list: SearchRequest[]): SearchRequest[] {
  const seen = new Set<string>();
  return list.filter(r => { const k = normalizeQuery(r.query); if (seen.has(k)) return false; seen.add(k); return true; });
}

/** Pull quoted phrases, site: filters and loose words out of a query string (used by the demo search engine and logs). */
export function parseQuery(query: string): { phrases: string[]; site: string | null; words: string[] } {
  const phrases = [...query.matchAll(/"([^"]+)"/g)].map(x => x[1]);
  const rest = query.replace(/"[^"]*"/g, ' ');
  const site = /site:(\S+)/i.exec(rest)?.[1]?.toLowerCase() ?? null;
  const words = rest.replace(/site:\S+/gi, ' ').split(/\s+/).map(w => w.trim()).filter(Boolean);
  return { phrases, site, words };
}
