// Browser flow: the artist discovery demo (discovery spec §90, ArtistFinder v2 UI) through the real UI.
// Run against a disposable workspace: node tests/e2e/discovery.mjs http://localhost:4100/  (needs google-chrome)
import { launch } from './cdp.mjs';
import { mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const HERE = fileURLToPath(new URL('.', import.meta.url));
const SHOTS = process.env.SHOTS ?? `${HERE}shots`;
mkdirSync(SHOTS, { recursive: true });
const BASE = process.argv[2] ?? 'http://localhost:4100/';
const b = await launch({ port: 9340 });
let step = 0; const T0 = Date.now();
const log = m => console.log(`${String(++step).padStart(2)}. [${((Date.now() - T0) / 1000).toFixed(1)}s] ${m}`);
const dialog = t => b.waitFor(`document.querySelector('[role=dialog]')?.innerText.includes(${JSON.stringify(t)})`, 10000, `dialog "${t}"`);
const dialogGone = () => b.waitFor(`!document.querySelector('[role=dialog]')`, 10000, 'dialog closed');
const dlg = l => b.click(l, '[role=dialog]');
const tab = t => b.click(t, '[role=tablist]');
const clickIn = async (text, label, scope = 'div, section, li, tr') => {
  const ok = await b.evaluate(`(() => {
    const cards = [...document.querySelectorAll(${JSON.stringify(scope)})].filter(d => d.innerText.includes(${JSON.stringify(text)}) && [...d.querySelectorAll('button, a')].some(x => x.innerText.trim() === ${JSON.stringify(label)}));
    cards.sort((a, b) => a.innerText.length - b.innerText.length);
    const btn = cards[0] && [...cards[0].querySelectorAll('button, a')].find(x => x.innerText.trim() === ${JSON.stringify(label)});
    if (!btn) return false; btn.scrollIntoView({ block: 'center' }); btn.click(); return true;
  })()`);
  if (!ok) throw new Error(`No "${label}" near "${text}"`);
  await b.sleep(200);
};
try {
  await b.go(BASE + '#/imports');
  await b.waitText('Upload export', 20000);
  await b.evaluate(`document.querySelectorAll('details').forEach(d => { d.open = true; })`);
  await clickIn('Excel: Rahul Sharma, Priya Shah, Amit Kumar', 'Upload now', 'li');
  await b.waitText('Artists in this file', 20000);
  await b.waitText('Find artist');
  await b.shot(`${SHOTS}/d01-import-artists.png`);
  log('Excel uploaded: artists listed with Find artist (no duplicates)');

  await clickIn('Rahul Sharma', 'Find artist', 'tr');
  await b.waitFor(`location.hash.includes('tab=evidence')`, 10000, 'evidence tab');
  await b.waitText('Finding Rahul Sharma', 10000);
  const rahulHash = (await b.evaluate('location.hash')).replace(/\?.*$/, '');
  await b.shot(`${SHOTS}/d02-progress.png`);
  log('Find artist: background search with step-by-step progress (Evidence tab)');
  await b.waitText('candidate profile', 30000);
  await b.sleep(400);
  await b.shot(`${SHOTS}/d03-candidates.png`, true);
  const txt = await b.text();
  for (const t of ['Possible artist', 'Strong candidate', 'Possible candidate', 'Different city', 'Keep separate', 'Found through', 'DEMO DATA']) if (!txt.includes(t)) throw new Error(`Missing on candidates: ${t}`);
  log('Candidates grouped as possible artists with evidence, conflicts, found-through and DEMO DATA labels');

  await b.evaluate(`(() => { const btn = [...document.querySelectorAll('button')].find(x => x.innerText.trim() === 'Open profile'); btn.click(); })()`);
  await dialog('DEMO DATA');
  await b.shot(`${SHOTS}/d04-preview.png`);
  await b.click('Close', '[role=dialog]'); await dialogGone();
  log('Open profile on demo data shows the fictional page (never a real site)');

  await clickIn('rahulsharma.sings', 'Verify all 6', 'section');
  await dialog('Verify Candidate'); await dlg('Verify all'); await dialogGone();
  await b.waitText('Verified artist', 15000);
  log('Candidate A verified: profiles saved as verified knowledge');
  await clickIn('djrahulsharma', 'Keep separate', 'section');
  await dialog('separate'); await dlg('Keep separate'); await dialogGone();
  await b.waitFor(`!document.body.innerText.includes('djrahulsharma') || document.body.innerText.includes('Rejected (')`, 10000, 'kept separate');
  log('Same-name DJ Rahul Sharma kept separate (offered to A099)');

  await tab('Connection Graph');
  await b.waitFor(`document.querySelectorAll('.react-flow__node').length > 5`, 15000, 'graph nodes');
  await b.sleep(800);
  await b.shot(`${SHOTS}/d05-graph.png`);
  log(`Connection graph rendered (${await b.evaluate(`document.querySelectorAll('.react-flow__node').length`)} nodes)`);
  await b.evaluate(`[...document.querySelectorAll('.react-flow__node')].find(n => n.innerText.includes('Joshua Singh'))?.dispatchEvent(new MouseEvent('click', { bubbles: true }))`);
  await b.sleep(300);
  await clickIn('Find connection', 'Find connection', 'section, div');
  await b.waitFor(`document.body.innerText.toLowerCase().includes('connection found')`, 15000, 'connection found');
  await b.sleep(600);
  await b.shot(`${SHOTS}/d06-find-connection.png`, true);
  log('Find connection: Rahul → “Dil Ka Safar” → Joshua Singh → verified contact');

  await clickIn('Joshua Singh', 'Create route', 'li');
  await b.waitFor(`document.body.innerText.toLowerCase().includes('route created')`, 10000, 'route created');
  await clickIn('Joshua Singh', 'Verify route', 'li');
  await dialog('Verify route'); await dlg('Verify route'); await dialogGone();
  await b.waitText('Route Ready', 10000);
  log('Route created as candidate, verified by a person → Route Ready');

  await b.go(BASE + '#/queue');
  await b.waitText('Contact Joshua Singh for an introduction to Rahul Sharma', 10000);
  await clickIn('Contact Joshua Singh for an introduction to Rahul Sharma', 'Do it', 'div');
  await dialog('Record contact');
  await b.fill('Channel', 'Phone'); await b.fill('Recipient', 'Rahul Sharma'); await b.fill('Result', 'Conversation Confirmed'); await b.fill('Evidence', 'Joshua introduced us; call');
  await dlg('Save contact attempt'); await dialogGone();
  log('Contact workflow continues from the queue (Contact Confirmed)');

  await b.go(BASE + '#/imports');
  await b.waitText('Upload export');
  await b.evaluate(`document.querySelectorAll('details').forEach(d => { d.open = true; })`);
  await clickIn('Excel: Rahul Sharma, Priya Shah, Amit Kumar', 'Upload now', 'li');
  await b.waitFor(`document.body.innerText.toLowerCase().includes('verified artist found')`, 20000, 'verified artist found');
  await b.sleep(1200);
  await b.shot(`${SHOTS}/d07-reupload.png`);
  log('Upload Rahul again: “Verified artist found”, profiles reused, no new search');

  await b.go(BASE + '#/imports');
  await b.waitText('Batch 002: Rahul Sharma, 17 songs');
  await b.sleep(300);
  await clickIn('Batch 002: Rahul Sharma, 17 songs', 'Upload now', 'li');
  await b.waitFor(`document.body.innerText.toLowerCase().includes('targeted discovery started')`, 20000, 'targeted discovery');
  await b.shot(`${SHOTS}/d08-b002.png`);
  log('Batch 002: Rahul recognised, 5 new songs, targeted discovery started');
  await b.go(BASE + `${rahulHash}?tab=evidence`);
  await b.waitFor(`document.body.innerText.includes('Targeted') && !document.body.innerText.includes('Finding Rahul Sharma')`, 30000, 'targeted job done');
  log('Targeted search finished (history keeps v1 and the targeted version)');
  await tab('Connection Graph');
  await b.waitText('Hawa Mein', 15000);
  await b.waitText('Riya Sen');
  await b.sleep(600);
  await b.shot(`${SHOTS}/d09-new-route.png`, true);
  log('Graph updated; potential new route Rahul → “Hawa Mein” → Riya Sen appears');

  await b.go(BASE + '#/discovery');
  await b.waitFor(`location.hash.startsWith('#/artists')`, 10000, 'old discovery link → Artists');
  await b.waitText('Action required'); await b.sleep(500);
  await b.shot(`${SHOTS}/d10-artists.png`);
  await b.go(BASE + '#/');
  await b.waitText('Discovery funnel'); await b.sleep(500);
  await b.shot(`${SHOTS}/d11-dashboard.png`);
  if (!(await b.text()).includes('SK-PV2.0.1')) throw new Error('Version footer missing');
  log('Old discovery link opens Artists; dashboard funnel; footer SK-PV2.0.1 present');
  console.log('\nDISCOVERY E2E PASSED. Console issues:', b.logs.length ? b.logs : 'none');
} catch (e) {
  console.error('\nFAILED at step', step + 1, ':', e.message);
  await b.shot(`${SHOTS}/dfail.png`);
  console.log(b.logs);
  process.exitCode = 1;
}
b.close();
