// Runs the four browser flows, each on a freshly restored demo workspace. Needs google-chrome.
//   node tests/e2e/run.mjs http://localhost:4100/             server mode: RESTORES THE DEMO DATA on that server first
//   node tests/e2e/run.mjs http://localhost:4200/ --no-reset  standalone build: every flow starts in a fresh browser profile
// Point it at a disposable workspace, never at one with real work in it.
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const HERE = fileURLToPath(new URL('.', import.meta.url));
const BASE = process.argv.find(a => /^https?:\/\//.test(a)) ?? 'http://localhost:4100/';
const reset = !process.argv.includes('--no-reset');
// The flows click Find artist many times: never against live search (real API quota and real results).
const cfg = await fetch(new URL('api/discovery/config', BASE)).then(r => r.json()).catch(() => null);
if (cfg?.mode === 'live') { console.error(`${BASE} runs LIVE search. Start the test server with DISCOVERY_DEMO_MODE=1.`); process.exit(1); }
for (const suite of ['v2-demo', 'discovery', 'demo-flow', 'interactions']) {
  if (reset) {
    const r = await fetch(new URL('api/admin/reset', BASE), { method: 'POST', headers: { 'content-type': 'application/json', 'x-user-id': 'u-swatantra' }, body: JSON.stringify({ mode: 'demo' }) }).catch(e => ({ ok: false, status: e.message }));
    if (!r.ok) { console.error(`Could not restore the demo workspace on ${BASE} (${r.status}). For the standalone build add --no-reset.`); process.exit(1); }
  }
  console.log(`\n▶ ${suite}`);
  const code = await new Promise(done => spawn(process.execPath, [`${HERE}${suite}.mjs`, BASE], { stdio: 'inherit' }).on('exit', done));
  if (code) process.exit(code);
}
console.log('\nAll browser flows passed.');
