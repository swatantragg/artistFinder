import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// "standalone" builds one self-contained HTML file that keeps its data in the browser (no server needed).
export default defineConfig(({ mode }) => ({
  plugins: [react(), tailwindcss(), ...(mode === 'standalone' ? [viteSingleFile()] : [])],
  define: { __STANDALONE__: JSON.stringify(mode === 'standalone') },
  build: { outDir: mode === 'standalone' ? 'dist-standalone' : 'dist', emptyOutDir: true, chunkSizeWarningLimit: 2000 },
  server: { port: 5173, proxy: { '/api': 'http://localhost:4000' } },
}));
