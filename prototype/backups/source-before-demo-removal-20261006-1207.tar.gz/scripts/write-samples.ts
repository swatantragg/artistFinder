// Writes the fictional demo import files to ./samples, for uploading by hand on the Imports page.
import { mkdirSync, writeFileSync } from 'node:fs';
import * as XLSX from 'xlsx';
import { DEMO_FILE_INFO, DEMO_XLSX, batch001Rows, demoFile, demoXlsxRows, templateCsv, toStandardCsv, DEMO_FILES, type DemoFileKind } from '../src/domain/catalog';

mkdirSync('samples', { recursive: true });
writeFileSync(`samples/${DEMO_FILES.b001}`, toStandardCsv(batch001Rows()));
for (const k of Object.keys(DEMO_FILE_INFO) as DemoFileKind[]) {
  const f = demoFile(k);
  const dir = k === 'b004fix' ? 'samples/corrected' : 'samples';
  mkdirSync(dir, { recursive: true });
  writeFileSync(`${dir}/${f.filename}`, f.csv);
}
writeFileSync('samples/g_amplify_import_template.csv', templateCsv());
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(demoXlsxRows()), 'Artists');
writeFileSync(`samples/${DEMO_XLSX.filename}`, XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }));
console.log('Wrote fictional sample files to ./samples (the corrected Batch 004 is in ./samples/corrected, same file name).');
